// Next.js 约定文件：register() 在服务器进程启动时执行一次，早于处理任何请求。
// 这里用它来确保下面两个模块里的"启动时副作用"（定时器、Redis 订阅）在进程一启动
// 就跑起来，而不是像之前那样要等第一个命中相关代码路径的请求把模块 import 进来才触发。
//
// 只在 nodejs runtime 下执行：这两个模块都用了 ioredis / Prisma，Edge runtime 不支持。
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    await import('./lib/view-count');
    await import('./lib/cache-broadcast');
  }
}
