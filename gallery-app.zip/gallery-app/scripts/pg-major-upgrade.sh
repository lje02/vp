#!/bin/bash
# Postgres 大版本升级脚本（比如 16 -> 18）。
#
# 大版本之间数据目录格式不兼容，不能像小版本那样直接换镜像重启就行——
# 新版本的 postgres 进程一看到旧版本的数据目录会直接拒绝启动。
# 唯一稳妥的路子就是：老版本先 pg_dump 导出全量数据，新版本起一个全新的空数据卷，
# 再把导出的数据 restore 进去。这个脚本把这套流程自动化了一遍，并且每一步危险操作
# （删旧数据卷）之前都会停下来让你确认，跟 ssh_harden.sh 的两阶段防锁死是一个思路：
# 出问题随时能用旧数据卷回滚，不会出现"删了才发现新库起不来"的情况。
#
# 用法：
#   ./scripts/pg-major-upgrade.sh                  # 交互模式，会提示确认
#   ./scripts/pg-major-upgrade.sh --yes             # 非交互，跳过确认（给自动化用）
#   ./scripts/pg-major-upgrade.sh --rollback        # 升级失败/不满意时，回滚到升级前的旧数据卷
#
# 前提：
#   - docker-compose.yml 里 postgres 那一节的 image 已经改成目标版本（比如 postgres:18-alpine）
#   - 当前目录下能找到 docker-compose.yml（脚本会自动 cd 到项目根目录）
#   - 磁盘剩余空间至少够放下一份数据库导出文件 + 一份数据卷镜像的拷贝
set -euo pipefail

cd "$(dirname "$0")/.."  # 确保在项目根目录执行，不管从哪调用这个脚本

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }
info() { echo -e "  $1"; }

AUTO_YES=0
ROLLBACK=0
for arg in "$@"; do
  case "$arg" in
    --yes|-y) AUTO_YES=1 ;;
    --rollback) ROLLBACK=1 ;;
    *) err "未知参数: $arg"; exit 1 ;;
  esac
done

confirm() {
  # $1 = 提示文案
  if [ "$AUTO_YES" -eq 1 ]; then
    return 0
  fi
  read -r -p "$1 [y/N] " reply
  [[ "$reply" =~ ^[Yy]$ ]]
}

# 从 docker compose 拿这个项目实际的卷名（带项目名前缀，比如 galleryapp_pgdata），
# 不要自己拼字符串猜，不同机器上项目目录名不一样，前缀会跟着变。
PGDATA_VOLUME=$(docker compose config --format json 2>/dev/null \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['volumes']['pgdata']['name'])" 2>/dev/null || true)

if [ -z "$PGDATA_VOLUME" ]; then
  err "找不到 pgdata 卷，先确认在项目根目录、docker-compose.yml 里有 postgres 服务"
  exit 1
fi

OLD_VOLUME_BACKUP="${PGDATA_VOLUME}_preupgrade_$(date +%Y%m%d%H%M%S)"

# ---- --rollback 模式：把升级前留的旧数据卷拷回来 ----
if [ "$ROLLBACK" -eq 1 ]; then
  echo "可用的升级前备份卷："
  docker volume ls --format '{{.Name}}' | grep "${PGDATA_VOLUME}_preupgrade_" || {
    err "没找到任何 ${PGDATA_VOLUME}_preupgrade_* 备份卷，没法回滚"
    exit 1
  }
  read -r -p "输入要回滚到的卷名（完整复制上面一行）: " RESTORE_VOL
  docker volume inspect "$RESTORE_VOL" > /dev/null 2>&1 || { err "卷不存在: $RESTORE_VOL"; exit 1; }

  confirm "会停掉当前服务，把 ${PGDATA_VOLUME} 里的数据换成 ${RESTORE_VOL} 的内容，确定？" || { warn "已取消"; exit 0; }

  docker compose down
  docker volume rm "$PGDATA_VOLUME" 2>/dev/null || true
  docker volume create "$PGDATA_VOLUME" > /dev/null
  docker run --rm -v "${RESTORE_VOL}:/from" -v "${PGDATA_VOLUME}:/to" alpine \
    sh -c "cp -a /from/. /to/"
  docker compose up -d
  ok "已回滚到 ${RESTORE_VOL} 的数据，postgres 正在用旧版本镜像启动（记得把 docker-compose.yml 里的 image 版本也改回去）"
  exit 0
fi

# ---- 正式升级流程 ----
echo "=== Postgres 大版本升级 ==="
info "数据卷: ${PGDATA_VOLUME}"

TARGET_IMAGE=$(docker compose config --format json 2>/dev/null \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['services']['postgres']['image'])")
info "docker-compose.yml 里配置的目标镜像: ${TARGET_IMAGE}"

RUNNING_IMAGE=$(docker compose ps -q postgres > /dev/null 2>&1 && docker inspect --format '{{.Config.Image}}' "$(docker compose ps -q postgres)" 2>/dev/null || echo "")
if [ -n "$RUNNING_IMAGE" ]; then
  info "当前正在跑的镜像: ${RUNNING_IMAGE}"
  if [ "$RUNNING_IMAGE" = "$TARGET_IMAGE" ]; then
    warn "当前跑的镜像已经和目标镜像一致了，可能已经升级过了，确认一下再继续"
  fi
else
  err "postgres 容器没在跑，先 docker compose up -d postgres 确保旧版本能正常启动再升级"
  exit 1
fi

if ! confirm "接下来会：1) 导出全量数据 2) 停服务 3) 备份旧数据卷 4) 用新镜像起一个空库 5) 导入数据。确定继续？"; then
  warn "已取消"
  exit 0
fi

# ---- 1. 全量导出（用 --clean --if-exists，导入时能覆盖式恢复，不用先手动建库） ----
mkdir -p backups
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
DUMP_FILE="backups/pre-upgrade-${TIMESTAMP}.sql.gz"

info "导出数据中..."
if ! docker compose exec -T postgres pg_dump -U gallery --clean --if-exists gallery | gzip > "$DUMP_FILE"; then
  err "导出失败，中止升级（旧库没动，可以放心排查）"
  rm -f "$DUMP_FILE"
  exit 1
fi
SIZE=$(du -h "$DUMP_FILE" | cut -f1)
ok "导出完成: ${DUMP_FILE}（${SIZE}）"

if [ ! -s "$DUMP_FILE" ]; then
  err "导出文件是空的，中止升级"
  exit 1
fi

# ---- 2. 停服务 ----
info "停止服务..."
docker compose down
ok "服务已停止"

# ---- 3. 备份旧数据卷（整卷复制一份，不是导出的 sql，双保险） ----
info "备份旧数据卷到 ${OLD_VOLUME_BACKUP} ..."
docker volume create "$OLD_VOLUME_BACKUP" > /dev/null
docker run --rm -v "${PGDATA_VOLUME}:/from" -v "${OLD_VOLUME_BACKUP}:/to" alpine \
  sh -c "cp -a /from/. /to/"
ok "旧数据卷已备份: ${OLD_VOLUME_BACKUP}（升级失败可以用 --rollback 恢复）"

# ---- 4. 清空原卷，用新镜像起一个全新的空库 ----
info "清空 ${PGDATA_VOLUME}，用新镜像初始化..."
docker volume rm "$PGDATA_VOLUME"
docker compose up -d postgres

info "等待新版本 postgres 就绪..."
for i in $(seq 1 30); do
  if docker compose exec -T postgres pg_isready -U gallery > /dev/null 2>&1; then
    break
  fi
  sleep 2
  if [ "$i" -eq 30 ]; then
    err "等了 60 秒新库还没就绪，去用 docker compose logs postgres 看看"
    exit 1
  fi
done
ok "新版本 postgres 已就绪: ${TARGET_IMAGE}"

# ---- 5. 导入数据 ----
info "导入数据中..."
if ! gunzip -c "$DUMP_FILE" | docker compose exec -T postgres psql -U gallery -d gallery > /tmp/pg-upgrade-restore.log 2>&1; then
  err "导入过程中有报错，看一下 /tmp/pg-upgrade-restore.log"
  warn "旧数据还在 ${OLD_VOLUME_BACKUP} 这个卷里，跑 ./scripts/pg-major-upgrade.sh --rollback 可以恢复"
  exit 1
fi

# --clean --if-exists 导出的 dump 正常会有一些"表不存在，跳过"之类的 notice，属于正常现象，
# 这里只挑真正的 ERROR 出来看，避免正常 notice 把人吓一跳
if grep -qi "^ERROR" /tmp/pg-upgrade-restore.log; then
  warn "导入日志里有 ERROR，建议检查一下（不一定致命，但建议看看）:"
  grep -i "^ERROR" /tmp/pg-upgrade-restore.log
fi
ok "数据导入完成"

# ---- 6. 起完整服务，跑个简单校验 ----
docker compose up -d
sleep 3
TABLE_COUNT=$(docker compose exec -T postgres psql -U gallery -d gallery -tAc \
  "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null || echo "0")
info "public schema 下有 ${TABLE_COUNT} 张表"

echo ""
ok "升级完成：${TARGET_IMAGE}"
info "旧数据卷备份留着，确认新库跑稳了（建议观察几天）再手动清理："
info "  docker volume rm ${OLD_VOLUME_BACKUP}"
info "导出的 sql 备份在: ${DUMP_FILE}"
info "如果发现不对，随时可以回滚: ./scripts/pg-major-upgrade.sh --rollback"
