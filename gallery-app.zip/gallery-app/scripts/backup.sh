#!/bin/bash
# 独立的数据库备份脚本，跟部署解耦，可以手动跑，也可以配 cron 定时跑。
# 本地保留最近 N 份；如果装了 aws-cli 并且 .env 里配好了 R2，还会顺手传一份到 R2 做异地备份。
#
# 用法：./scripts/backup.sh
set -e
set -o pipefail  # 下面 pg_dump | gzip 是个管道，不加这个的话 bash 只看最后一个命令(gzip)的退出码，
                  # pg_dump 中途报错、gzip 收到空输入照样能正常退出 0，会把失败的备份误判成成功

cd "$(dirname "$0")/.."  # 确保在项目根目录执行，不管从哪调用这个脚本

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; }

LOCAL_KEEP=14  # 本地保留最近多少份

# 数据库现在是 pg-redis-shared.sh 部署在共享库那台机器上的远程 Postgres，
# 不再是本项目自带的容器，所以直接用 DATABASE_URL 连过去 pg_dump，
# 而不是 docker compose exec 到本地的 postgres 服务。
if [ -f .env ]; then
  # shellcheck disable=SC1091
  set -a; source .env; set +a
fi

if [ -z "$DATABASE_URL" ]; then
  err ".env 里没有 DATABASE_URL，检查一下配置"
  exit 1
fi

if ! command -v pg_dump &> /dev/null; then
  err "本机没装 pg_dump，装一下 PostgreSQL 客户端工具再试（要跟共享库的大版本对上，参考 scripts/first-deploy.sh 里的安装步骤，别直接装发行版默认的 postgresql-client）："
  echo "    sudo apt install -y postgresql-client-18   # 需要先加 PGDG 源"
  exit 1
fi

mkdir -p backups
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_FILE="backups/backup-${TIMESTAMP}.sql.gz"

# ---- 1. 本地备份 ----
# pg_dump 的 stderr 单独存一份，正常情况用不上，只有失败时才拿来判断失败原因、
# 给出更精确的提示（尤其是"客户端版本落后于服务器"这种，能直接告诉你该装哪个版本，
# 不用等它报一堆不好懂的英文再自己去查）
PG_DUMP_ERR=$(mktemp)
if ! pg_dump "$DATABASE_URL" --clean --if-exists 2>"$PG_DUMP_ERR" | gzip > "$BACKUP_FILE"; then
  if grep -q "server version mismatch" "$PG_DUMP_ERR"; then
    SERVER_MAJOR=$(grep -oP 'server version: \K[0-9]+' "$PG_DUMP_ERR" | head -1)
    CLIENT_VER=$(pg_dump --version | grep -oP '\(PostgreSQL\) \K[0-9.]+')
    err "本机 pg_dump 是 ${CLIENT_VER}，共享库服务器是 ${SERVER_MAJOR}.x，版本落后了（pg_dump 要求客户端版本 >= 服务器版本）"
    echo "  装一下匹配版本的客户端（PGDG 官方源）："
    echo "    sudo install -d /usr/share/postgresql-common/pgdg"
    echo "    sudo curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc"
    echo "    echo \"deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] https://apt.postgresql.org/pub/repos/apt \$(lsb_release -cs)-pgdg main\" | sudo tee /etc/apt/sources.list.d/pgdg.list"
    echo "    sudo apt-get update && sudo apt-get install -y postgresql-client-${SERVER_MAJOR}"
    echo "  装完如果 pg_dump --version 还是显示旧版本，切一下默认版本："
    echo "    sudo update-alternatives --config pg_dump && sudo update-alternatives --config psql"
  else
    err "备份失败，检查一下能不能连到共享库（WireGuard 是否连通、DATABASE_URL 是否正确），报错详情："
    sed 's/^/  /' "$PG_DUMP_ERR"
  fi
  rm -f "$BACKUP_FILE" "$PG_DUMP_ERR"
  exit 1
fi
rm -f "$PG_DUMP_ERR"

# 再做一道内容层面的兜底检查：正常的 pg_dump 输出是以 "--" 开头的 SQL 注释起手的，
# 不是的话大概率是空文件或者被截断的坏备份——pipefail 已经能兜住大部分情况，
# 这一步是双保险，防止某些边缘情况下管道退出码看着正常、内容其实是空的
if [ "$(gzip -dc "$BACKUP_FILE" 2>/dev/null | head -c 2)" != "--" ]; then
  err "备份文件内容看起来是空的或者不完整，不当成功处理"
  rm -f "$BACKUP_FILE"
  exit 1
fi

SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
ok "本地备份完成: ${BACKUP_FILE}（${SIZE}）"

# 只留最近 N 份，避免把 VPS 磁盘占满
ls -t backups/backup-*.sql.gz 2>/dev/null | tail -n +$((LOCAL_KEEP + 1)) | xargs -r rm --

# ---- 2. 异地备份到 R2（可选，条件不满足就跳过，不影响本地备份的结果） ----
if ! command -v aws &> /dev/null; then
  warn "没装 aws-cli，跳过异地备份。想要异地备份的话装一下："
  echo "    sudo apt install -y awscli   # 或 pip install awscli"
  exit 0
fi

if [ -z "$S3_ENDPOINT" ] || [ -z "$S3_ACCESS_KEY_ID" ] || [ -z "$S3_SECRET_ACCESS_KEY" ] || [ -z "$S3_BUCKET" ]; then
  warn ".env 里 R2 相关变量没配全，跳过异地备份"
  exit 0
fi

export AWS_ACCESS_KEY_ID="$S3_ACCESS_KEY_ID"
export AWS_SECRET_ACCESS_KEY="$S3_SECRET_ACCESS_KEY"
export AWS_DEFAULT_REGION="auto"  # R2 不看这个值，但 aws-cli 要求必须传一个，不传部分版本会连不上

# aws-cli 2.22+ / botocore 1.36+ 默认会给 PutObject 这类写操作带上校验和(checksum)请求头，
# 这个头也会参与签名计算——R2 对这个头的处理跟 AWS 官方不完全一致，结果就是明明密钥、权限都对，
# 写操作却报 SignatureDoesNotMatch（列表这类只读操作不受影响，所以排查时 aws s3 ls 是通的）。
# 这两个变量让 aws-cli 退回老行为：只在服务端明确要求时才计算/校验校验和，读操作不受影响。
export AWS_REQUEST_CHECKSUM_CALCULATION=WHEN_REQUIRED
export AWS_RESPONSE_CHECKSUM_VALIDATION=WHEN_REQUIRED

if aws s3 cp "$BACKUP_FILE" "s3://${S3_BUCKET}/db-backups/$(basename "$BACKUP_FILE")" \
    --endpoint-url "$S3_ENDPOINT" --only-show-errors; then
  ok "异地备份已上传到 R2: db-backups/$(basename "$BACKUP_FILE")"
  echo "  建议在 Cloudflare R2 控制台给 db-backups/ 这个前缀设一条生命周期规则，"
  echo "  比如「90 天后自动删除」，省得手动清理远端旧备份"
else
  warn "上传到 R2 失败，本地备份还在，不影响这次备份结果"
fi
