#!/usr/bin/env python3
"""
.env 文件的读写工具，被 scripts/update-shared-infra.sh 调用。

用 sed 硬拼字符串改 .env 的问题：密码/密钥里只要出现 sed 的特殊字符
（/ & # 换行等），拼出来的表达式要么直接语法错误，要么把替换结果搞乱，
且不容易第一时间发现（.env 语法本身很宽松，坏掉的行不会报错，只会在
应用启动时读到错误的值，排查起来还得回头怀疑到这一层）。

改用 Python 的好处不是"更高级"，而是：
- 精确匹配整行 KEY=... 再整行替换，不做任何跨行的字符串拼接/正则替换
- 值本身完全不经过 shell/sed 的转义规则，用什么字符都不会破坏文件结构
- 处理"变量存在但被注释掉"（.env.example 里 REDIS_URL/WG_IP 这种可选项
  就是 "# KEY=" 的形式）和"变量完全不存在，需要追加"两种情况

用法：
  python3 env_edit.py get   <ENV_FILE> <KEY>              打印当前值（找不到打印空字符串，退出码 1）
  python3 env_edit.py set   <ENV_FILE> <KEY> <VALUE>      设置值（存在则原地替换/取消注释，不存在则追加）
  python3 env_edit.py mask  <ENV_FILE> <KEY>              打印脱敏后的当前值，用于交互时展示（不吐出明文）
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

# 判断是不是"敏感"变量，展示时打码。按变量名关键字匹配，宁可多打码
# 也不要漏打码——这份名单以后加新的密钥类变量时记得同步加关键字。
SECRET_KEYWORDS = ('SECRET', 'PASSWORD', 'PASS', 'KEY', 'TOKEN')


def is_secret_key(key: str) -> bool:
    # NEXT_PUBLIC_TURNSTILE_SITE_KEY 例外：虽然名字里带 KEY，但 Turnstile 的
    # site key 设计上就是公开的（会被打进前端 JS，浏览器里谁都能看到），
    # 打码反而误导人以为它需要保密。
    if key == 'NEXT_PUBLIC_TURNSTILE_SITE_KEY':
        return False
    return any(kw in key for kw in SECRET_KEYWORDS)


def mask_value(value: str) -> str:
    if not value:
        return '(空)'
    if len(value) <= 4:
        return '*' * len(value)
    # 只留最后 4 位，够用来确认"是不是我以为的那个值"，不足以泄露
    return '*' * (len(value) - 4) + value[-4:]


def read_lines(env_path: Path) -> list[str]:
    if not env_path.exists():
        print(f'找不到文件：{env_path}', file=sys.stderr)
        sys.exit(1)
    return env_path.read_text(encoding='utf-8').splitlines(keepends=True)


def find_key_line(lines: list[str], key: str):
    """
    返回 (index, is_commented) 或 None。
    只精确匹配行首是 "KEY=" 或 "# KEY="/"#KEY="（允许 # 后面有 0-1 个空格），
    不匹配"值里恰好包含这个字符串"这种情况（比如 DATABASE_URL 的值里
    可能包含 REDIS 这种子串——虽然目前变量名不会互相冲突，但精确匹配
    比"看着像"更可靠，以后加新变量也不用担心命名冲突）。
    """
    uncommented = re.compile(rf'^{re.escape(key)}=')
    commented = re.compile(rf'^#\s?{re.escape(key)}=')
    for i, line in enumerate(lines):
        if uncommented.match(line):
            return i, False
        if commented.match(line):
            return i, True
    return None


def get_value(env_path: Path, key: str) -> str | None:
    lines = read_lines(env_path)
    hit = find_key_line(lines, key)
    if hit is None:
        return None
    idx, commented = hit
    line = lines[idx].rstrip('\n')
    if commented:
        # 被注释掉的行本身不算"已配置"，返回 None 让调用方知道这是"未设置"状态，
        # 而不是返回注释里写的占位符文本（比如 "replace_with_random_secret"）
        return None
    _, _, value = line.partition('=')
    return value


def set_value(env_path: Path, key: str, value: str) -> None:
    lines = read_lines(env_path)
    hit = find_key_line(lines, key)
    new_line = f'{key}={value}\n'

    if hit is not None:
        idx, _ = hit
        lines[idx] = new_line
    else:
        # 完全没这一行（既不存在也没被注释掉过），追加到文件末尾。
        # 保证文件以换行结尾再追加，避免新行跟最后一行内容粘在一起。
        if lines and not lines[-1].endswith('\n'):
            lines[-1] += '\n'
        lines.append(new_line)

    # 原子写入：先写临时文件再 rename，避免脚本中途被打断（比如 Ctrl+C）
    # 导致 .env 只写了一半、内容截断
    tmp_path = env_path.with_suffix(env_path.suffix + '.tmp')
    tmp_path.write_text(''.join(lines), encoding='utf-8')
    tmp_path.replace(env_path)


def main():
    if len(sys.argv) < 4:
        print(__doc__, file=sys.stderr)
        sys.exit(2)

    action, env_file, key = sys.argv[1], sys.argv[2], sys.argv[3]
    env_path = Path(env_file)

    if action == 'get':
        value = get_value(env_path, key)
        if value is None:
            sys.exit(1)
        print(value)
    elif action == 'mask':
        value = get_value(env_path, key)
        print(mask_value(value) if value is not None else '(未设置)')
    elif action == 'set':
        if len(sys.argv) < 5:
            print('set 需要第 4 个参数：VALUE', file=sys.stderr)
            sys.exit(2)
        set_value(env_path, key, sys.argv[4])
    else:
        print(f'未知操作：{action}（只支持 get/set/mask）', file=sys.stderr)
        sys.exit(2)


if __name__ == '__main__':
    main()
