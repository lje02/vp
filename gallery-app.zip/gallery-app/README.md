# 图集网站

Next.js + PostgreSQL + Cloudflare R2 打造的图集展示站。访客只读，管理员通过后台上传/管理图集。

## 技术栈

- **Next.js 14**（App Router）：前台展示走 ISR 静态缓存，后台管理走动态渲染
- **PostgreSQL + Prisma**：存图集/图片元数据。数据库不是本项目自带的容器，而是连接 [`pg-redis-shared.sh`](../pg-redis-shared.sh) 部署在 WireGuard 内网的共享 Postgres 实例
- **Cloudflare R2**：存原图和缩略图，前端直传，不经过服务器
- 没有用 Redis：访问量不大时，ISR 页面缓存 + CDN 缓存图片已经足够快，详见项目讨论

## 本地开发

```bash
# 1. 安装依赖
npm install

# 2. 复制环境变量并填写
cp .env.example .env

# 3. 在共享库那台机器上创建库（只需一次），然后把 WG IP + 密码填进 .env 的 DATABASE_URL
#      ./pg-redis-shared.sh add-db /srv/pg-infra gallery gallery
#    本机开发也要能连上同一个 WireGuard mesh，才能通到共享库

# 4. 跑数据库迁移
npx prisma migrate dev --name init

# 5. 创建管理员账号
npm run create-admin -- admin@example.com yourpassword

# 6. 启动开发服务器
npm run dev
```

访问 `http://localhost:3000` 看前台，`http://localhost:3000/monkey/login` 登录后台。

## R2 配置步骤

1. 登录 Cloudflare Dashboard → R2 → 创建一个 Bucket（比如 `gallery`）
2. 在 Bucket 设置里开启「公开访问」，或者绑定一个自定义域名（推荐，速度更稳定、可配合 Cloudflare CDN 缓存规则）
3. R2 → 管理 API 令牌 → 创建一个具有读写权限的 API Token，拿到 Access Key ID / Secret Access Key
4. 把 Endpoint、Access Key、Bucket 名、公开访问域名填进 `.env`

## 生产部署（Docker）

### 首次部署

**先决条件**：数据库不在这个项目里，是连的 [`pg-redis-shared.sh`](../pg-redis-shared.sh) 部署在别的机器上的共享 Postgres，本机（VPS）要先加入同一个 WireGuard mesh，并且在共享库那台机器上先建好库：

```bash
./pg-redis-shared.sh add-db /srv/pg-infra gallery gallery
```

在 VPS 上 clone 好仓库后，一个脚本搞定：装 Docker（如果没装）、生成 `.env`（会话密钥自动生成，数据库连接和 R2 那几项会在终端里交互式问你，一项项输入就行，不用自己去开编辑器改文件）、构建启动、创建管理员账号。

```bash
git clone git@github.com:你的用户名/仓库名.git gallery-app
cd gallery-app
./scripts/first-deploy.sh
```

`docker-compose.yml` 里 3000 端口只绑在 VPS 的 `127.0.0.1` 上，不对公网暴露（Docker 发布端口是直接改 `iptables`，跑在 `ufw` 规则前面生效，光靠防火墙"只放行 22/80/443"是挡不住 Docker 自己开的端口的，所以干脆从源头上不监听公网接口）。

跑完之后想先测试一下，有两种办法：
- 直接在 VPS 上跑 `curl http://localhost:3000` 看看有没有响应
- 或者本地执行 `ssh -L 3000:localhost:3000 你的VPS` 建个隧道，然后浏览器打开 `http://localhost:3000`

正式上线前配好域名 + HTTPS 反代（推荐 Caddy，配置简单还能自动续证书），反代进程本身跑在 VPS 上，通过 `localhost:3000` 就能连到容器，不需要额外开放 3000 端口。

### 日常更新

改完代码 push 到 GitHub 后，在 VPS 上：

```bash
./scripts/deploy.sh
```

这个脚本会依次：拉最新代码 → 部署前自动备份一次数据库（存在 `backups/` 目录，保留最近 10 份）→ 重新构建镜像 → 重启服务并跑数据库迁移 → 健康检查确认应用真的起来了 → 清理没用到的旧镜像。任何一步失败都会停下来报错，不会硬着头皮往下走。

### 依赖自动更新（Renovate）

`Dockerfile` 里 Node 版本、`package.json` 里的 npm 依赖都是锁死具体版本的（可复现构建，见 `Dockerfile` 里的注释），代价是需要有人盯着有没有新版本、尤其是安全更新。这部分交给 [Renovate](https://github.com/apps/renovate) 自动做：

1. 去 https://github.com/apps/renovate 给这个仓库装上 Renovate GitHub App（几次点击，免费）。
2. 装完之后 Renovate 会自己读取仓库根目录的 `renovate.json`，按里面配的规则定期检测：
   - `Dockerfile` 里三个 stage 的 `node:*-alpine` 有新 patch 版本 → 开一个 PR，三行一起改
   - `package.json` 里的 npm 依赖有更新 → patch/minor 打包成一个 PR，major 版本（可能有 breaking change）单独一个 PR
   - 任何依赖被标记安全漏洞 → 额外打 `security` 标签、更高优先级出 PR
3. 都不会自动合并——PR 开出来之后自己 review 一下 changelog / 安全公告，确认没问题再点合并，走一遍 `./scripts/deploy.sh` 照常发布。

### 数据库备份

**别只依赖部署时的备份**——如果你几周不部署一次，中间数据全靠运气。建议配一个每天自动跑的定时备份：

```bash
crontab -e
# 加一行，每天凌晨 3 点自动备份
0 3 * * * cd /path/to/gallery-app && mkdir -p backups && ./scripts/backup.sh >> backups/backup.log 2>&1
```

`scripts/backup.sh` 做两件事：
1. **本地备份**：`pg_dump` 出来 gzip 压缩，存到 `backups/` 目录，自动保留最近 14 份，旧的自动删
2. **异地备份到 R2**（可选，条件不满足会自动跳过，不影响本地备份）：如果 VPS 上装了 `aws-cli`（`sudo apt install awscli` 或 `pip install awscli`）并且 `.env` 里 R2 配置齐全，会顺手把备份也传一份到 R2 的 `db-backups/` 目录下

**为什么要传一份去 R2**：本地备份只能防"手滑删错数据"，防不住"服务器本身挂了/被黑/硬盘坏了"。备份和数据库放在同一台机器上，等于没做异地容灾。R2 存储费用很低，存点数据库备份基本可以忽略不计。

建议再去 Cloudflare R2 控制台给 `db-backups/` 这个前缀配一条生命周期规则（比如「90 天后自动删除」），远端的旧备份就不用你手动清理了。

`deploy.sh` 每次部署前也会调用这个备份脚本，双重保险。

### 定时发布

后台编辑图集时可以设一个"定时发布"时间：图集会先以 `DRAFT` 状态存着（不出现在任何公开页面），到点之后自动转成 `PUBLISHED`。"到点自动转"这一步不是靠网页挂着不关，是靠一个 cron 定时跑的脚本：

```bash
crontab -e
# 加一行，每 5 分钟检查一次有没有到期的定时发布图集
*/5 * * * * cd /path/to/gallery-app && docker compose exec -T web node prisma/publish-scheduled.cjs >> backups/publish-scheduled.log 2>&1
```

5 分钟只是个不错的默认值——定时发布这东西本来也不需要精确到秒，间隔太短除了多消耗一点点资源没有别的好处。没有到期的图集时脚本只会打一行日志就退出，不会做任何写入。

多节点部署也不用每个节点都配这条 cron，配一个节点上就够：脚本发布完图集之后会通过 Redis 广播缓存失效通知，所有节点都会收到并各自刷新缓存（跟后台保存设置/分类那套广播机制是同一套，见 `lib/cache-broadcast.ts`）。

### 恢复数据库

直接跑，不用记文件名，会弹出交互菜单：

```bash
./scripts/restore.sh
```

```
== 选择要恢复的备份 ==

本地备份：
   1) backup-20260719-030000.sql.gz  (12M, 2026-07-19 03:00)
   2) backup-20260718-030000.sql.gz  (12M, 2026-07-18 03:00)

R2 异地备份（本地没有，选了会先下载）：
  r1) backup-20260717-030000.sql.gz

输入序号（本地填数字，远端填 r1/r2 这种）:
```

选本地的备份直接输入数字；选 `r1` 这种会先从 R2 自动下载到本地再恢复。确认要恢复后还会再问一遍 `yes` 二次确认。

如果是写脚本调用、不想每次交互，也可以照旧直接给文件路径跳过菜单：
```bash
./scripts/restore.sh backups/backup-20260719-030000.sql.gz
```

`restore.sh` 在真正覆盖数据库之前，会**先给当前数据库也存一份快照**（`backups/before-restore-*.sql.gz`），万一发现选错了备份文件、恢复错了，还能再用这份快照退回来，不会不可逆地把当前数据弄丢。

**一个建议**：备份这种东西，没实际恢复过一次的备份不能算数。上线后找个时间，故意在测试环境走一遍完整的恢复流程，确认真的能用，比一直"应该没问题"踏实。

## 目录结构

```
app/
  page.tsx                     首页（图集列表，支持排序/分类筛选，ISR 缓存）
  [slug]/page.tsx              图集详情页 + 标签页（扁平路径，一个文件两种用途，见文件内注释）
  albums/[slug]/page.tsx       历史遗留：308 重定向到 /slug，兼容外部老链接，不要删
  tags/、search/、about/       标签云、搜索、关于页
  feed.xml/route.ts            RSS 订阅
  login/、register/            前台用户登录注册（私密相册账号授权用）
  monkey/                      后台管理
    login/                     管理员登录页（不受 (protected) 分组保护）
    (protected)/                需要管理员 session 才能访问，见 layout.tsx 里的 requireAdminPage()
      albums/[id]/edit/         编辑图集（含分享链接管理面板 ShareLinksPanel.tsx）
      AlbumsTable.tsx           图集列表 + 批量操作
      ViewTrendChart*.tsx       浏览趋势图（recharts）
  api/
    monkey/                    管理员专用接口，每个 handler 都过 requireAdminApi()
      albums/bulk/              批量操作
      albums/[id]/share-links/  分享链接增删
    albums/[slug]/photos       私密相册照片（账号授权 或 分享链接 token 二选一放行）
    albums/[slug]/view         浏览量上报
    login/、register/、me/     前台用户账号
lib/
  db.ts                        Prisma client
  storage.ts                   R2（S3 兼容）客户端，预签名上传/下载 URL
  auth.ts                      管理员会话（JWT + httpOnly cookie），requireAdminPage/requireAdminApi
  user-auth.ts                 前台用户会话
  view-count.ts                浏览量攒批写库 + 每日明细（AlbumViewDaily，给趋势图用）
  exif-format.ts               EXIF 原始 tag 转人类可读字符串
  seeded-shuffle.ts            确定性洗牌，首页/标签页"随机排序"用
proxy.ts                       保护 /monkey 和 /api/monkey（Next.js 16 里 middleware.ts 改名叫 proxy.ts）
prisma/
  schema.prisma                数据库模型
  publish-scheduled.ts         定时发布脚本，cron 跑，见「定时发布」那节
  create-admin.ts              创建/重置管理员账号
  backfill-title-pinyin.ts     拼音搜索字段一次性回填脚本，见「拼音搜索」那节
renovate.json                  依赖自动更新配置
```

## 分类 / 封面 / 分页

- **分类是两级结构，大类和子分类都能挂图集**：先建"大类"（比如「城市风景」），可以在其下建"子分类"（比如「纽约」「东京」）细分。新建图集时选好大类后，子分类是可选的——不选就直接把图集挂在大类下，选了就挂在对应子分类下
  - 后台 `/monkey/categories`：先建大类（大类下拉框选"顶级分类"），再建子分类（大类下拉框选对应的大类）
  - 首页导航是两行：第一行大类 Tab，选中某个大类后，第二行会展开它下面的子分类 Tab；筛选大类时，会同时显示直接挂在大类下的图集和它所有子分类下的图集
  - 删除一个有子分类的大类时，子分类会自动升级成顶级分类（不会被一起删掉）
  - 目前只支持两级（大类 → 子分类），暂不支持无限层级嵌套
- **封面**：新建图集时选好图片后，下方会出现缩略图预览，点一下就能指定哪张作为封面（默认第一张）
- **分页**：首页每页 24 个图集（`lib/pagination.ts` 里的 `PAGE_SIZE` 可以改），通过 `?page=2` 翻页，配合分类筛选可以叠加使用（`?category=xxx&page=2`）。页码组件带省略号（`1 … 4 5 [6] 7 8 … 20`），页数再多也不会把一排挤爆
- **移动端适配**：前台首页/详情页/分类导航本身就是响应式的（网格 2→3→4 列随屏幕宽度变化）；后台管理列表在窄屏（<640px）下会自动从表格切换成卡片布局，避免横向滚动

如果是已经跑起来的旧数据库，加这个功能后需要重新跑一次迁移：

```bash
npx prisma migrate dev --name add_category_hierarchy_and_pagination
# 生产环境：
docker compose exec web node_modules/.bin/prisma migrate deploy
```

## 网站外观设置

后台 `/monkey/settings` 可以改：网站标题、SEO 描述、背景色、文字颜色、强调色（按钮和高亮用的颜色）。这些设置存在数据库的 `SiteSetting` 表里（只有一行数据），改完点保存立即在前台生效，不用重新部署。

实现原理：颜色是通过 CSS 变量（`--bg-color` / `--text-color` / `--accent-color`）注入到 `<body>` 上的。全站所有次要文字、边框、卡片底色都不是写死的颜色值，而是引用 `globals.css` 里基于 `--text-color` 用 `color-mix()` 派生出来的一组 `--fg-5` ~ `--fg-80`（数字代表透明度），背景选深色还是浅色，这些派生色都能保证够用的对比度，不会出现"文字颜色跟背景糊在一起看不清"的情况。保存设置时会调用 `revalidatePath('/', 'layout')`，让所有页面共用的布局缓存立即失效，下一次访问就是新样式。

如果是已经跑起来的旧数据库，需要重新跑一次迁移让 `SiteSetting` 表生效：

```bash
npx prisma migrate dev --name add_site_settings
# 生产环境：
docker compose exec web node_modules/.bin/prisma migrate deploy
```

## 拼音搜索

`/search` 除了标题/简介/标签的字面匹配，现在也支持拼音搜索：打整段拼音（比如"meihua"）或者首字母缩写（"mh"）都能搜到标题里含"梅花"的图集。原理是创建/编辑图集时用 `pinyin-pro` 把标题转成拼音存进 `Album.titlePinyin` 这一列（`lib/pinyin.ts`），搜索时跟标题、简介一起走同一次 `OR` 查询，同样建了 pg_trgm 索引加速。

如果是已经跑起来的旧数据库，加这个功能后需要：

```bash
# 1. 跑迁移，加 titlePinyin 这一列 + 索引
npx prisma migrate dev --name title_pinyin
# 生产环境：
docker compose exec web node_modules/.bin/prisma migrate deploy

# 2. 回填现有图集的拼音值（新迁移只是加了列，不会自动帮你把已有标题转成拼音）
npm run backfill-title-pinyin
# 生产环境：
docker compose exec web node prisma/backfill-title-pinyin.cjs
```

回填脚本可以重复跑，不会出错（幂等）。跑完之后，新建/编辑图集时会自动算好这一列，不需要再手动跑。

## License

本项目使用 [Apache License 2.0](./LICENSE) 开源。

## Next.js 版本

项目用的是 Next.js 16（写这个 README 时的最新稳定版），配套 React 19。升级时有两个框架层面的破坏性改动需要注意，代码里已经处理好了，仅供了解：

- **Next 15 起，`cookies()`、动态路由的 `params`、页面的 `searchParams` 全部变成异步**，要 `await` 之后才能用（比如 `const { slug } = await params`）。如果你之后基于这套脚手架加新页面/接口，记得也用这个写法，不然会报错或拿不到值。
- **Next 16 移除了 `next lint` 命令**，`package.json` 里的 `lint` 脚本已经改成直接跑 `eslint .`，配置在 `eslint.config.mjs`（ESLint 9 的 flat config 格式，不是旧版的 `.eslintrc.json`）。
- **Next 16 把 `middleware.ts` 改名成了 `proxy.ts`**，导出的函数名也从 `middleware` 改成了 `proxy`，项目根目录下现在是 `proxy.ts` 而不是 `middleware.ts`。旧写法目前还能用（只是有弃用警告），但迟早会被彻底砍掉。
- Next 16 要求 **Node.js ≥ 20.9**，Dockerfile 里的 `node:20-alpine` 满足这个要求。
- Next 16 默认用 **Turbopack** 跑 `next dev` / `next build`，一般不需要额外配置。

如果之后 Next 又出新的大版本，想升级的话，官方有个自动化工具可以先跑一下试试：
```bash
npx @next/codemod@canary upgrade latest
```

## 密码强度 & 登录防爆破

- **创建/重置管理员密码时会校验强度**：至少 10 位，同时包含字母和数字，还会拦截几个常见弱密码（比如 `password`、`12345678`）。校验逻辑在 `lib/password.ts`，`prisma/create-admin.ts` 脚本会用到，密码不合格会直接报错退出，不会创建账号
- **登录接口带失败次数锁定**：同一个账号连续输错 5 次密码，会锁定 15 分钟（这段时间内直接拒绝，不再校验密码，防止暴力破解）。这几个参数（`MAX_ATTEMPTS` / `LOCK_MINUTES`）写在 `app/api/monkey/login/route.ts` 顶部，想调可以直接改
- 失败次数存在 `AdminUser` 表的 `failedAttempts` / `lockedUntil` 字段里，没有额外依赖 Redis
- **已知的小缺口**：限流是按账号锁定的，如果攻击者对着一个**不存在**的邮箱疯狂尝试，不会被锁定（因为没有对应的 `AdminUser` 记录可以计数）。对于只有 1~2 个管理员的小站基本没什么风险，如果要更严格，可以再加一层按 IP 的限流（这个可以用 Postgres 记 IP+时间戳，或者交给 Cloudflare 的 Rate Limiting 规则做，不用改代码）

如果是已有数据库，需要重新跑一次迁移让新字段生效：

```bash
npx prisma migrate dev --name add_login_lockout
# 生产环境：
docker compose exec web node_modules/.bin/prisma migrate deploy
```

## 已知坑：Prisma 在 Alpine 镜像里报 libssl 找不到

如果构建时看到类似这样的报错：

```
Error loading shared library libssl.so.1.1: No such file or directory
```

原因是 `node:20-alpine` 用的 Alpine 版本自带 OpenSSL 3.0，但 Prisma 默认按 OpenSSL 1.1 编译引擎，版本对不上。这个项目已经在 `prisma/schema.prisma` 里指定了 `binaryTargets = ["native", "linux-musl-openssl-3.0.x"]`，并且 Dockerfile 里也装好了 `openssl`（builder 和 runner 两个阶段都要装，一个编译时用一个运行时用），正常情况不会遇到。如果你改了 Node 镜像版本或者自己调整了 Dockerfile，记得这两处别漏掉。

另外要注意：**`docker build` 阶段不能依赖真实数据库**。`docker compose build` 和 `docker compose up` 是两个独立步骤，构建镜像的时候 Postgres 服务不一定已经启动，也不一定网络互通。所以这个项目故意没有给动态路由页面用 `generateStaticParams`（那个函数会在构建时就去查数据库），全部走纯 ISR：第一次真实访问时才生成页面并缓存，效果跟静态生成一样，只是把"生成时机"从构建阶段挪到了首次访问。以后加新页面时如果想用 `generateStaticParams` 预生成，要么确保构建环境真的能连到数据库，要么就跟现在一样不用它。

## 已知坑：生产环境里 create-admin 脚本用不了 tsx

`prisma/create-admin.ts` 本地开发时用 `npx tsx` 直接跑 TypeScript 很方便，但生产镜像是 Next.js 的 standalone 输出，只会打包"应用本身用到的依赖"，`tsx`/`esbuild` 这些只在 CLI 脚本里用到的包不会被自动带进去，手动一个个 `COPY` 进 Dockerfile 也很容易漏（一开始漏了 `esbuild`，改完发现还漏了 `lib/` 目录，没完没了）。

现在的做法是：**构建镜像时把这个脚本用 esbuild 编译打包成一个独立的 `prisma/create-admin.cjs`**（`@prisma/client` 保留外部引用，其余全部打包进这一个文件），生产环境跑的是这个编译产物，不再依赖 `tsx`：

```bash
docker compose exec web node prisma/create-admin.cjs admin@example.com yourpassword
```

本地开发不受影响，`npm run create-admin` 还是走 `tsx` 直接跑源码。如果你以后想加别的一次性脚本（比如批量导入图集之类的），照这个模式来：本地用 `tsx` 方便调试，生产环境在 Dockerfile 里加一行 `esbuild` 编译命令，不要指望把 `node_modules` 里的东西一个个手动 `COPY` 全。

## 已知坑：改了 R2 域名，图片全变问号

`next.config.js` 里的图片域名白名单（`images.remotePatterns`）是 **Next.js 构建时** 写死进产物里的，不是运行时读取。`docker build` 那一步是看不到 `.env` 文件的（`.env` 只在容器**运行**的时候才会被读到），所以光改 `.env` 里的 `S3_PUBLIC_HOSTNAME` 没用，图片会一直显示成裂图/问号（Next Image 发现域名不在白名单里直接拒绝加载）。

这个项目已经通过 Docker build arg 把 `.env` 里的 `S3_PUBLIC_HOSTNAME` 在构建时传进去了（`docker-compose.yml` 的 `build.args` + `Dockerfile` 里的 `ARG`/`ENV`），正常 `docker compose up -d --build` 就没问题。**但要记住一点**：以后如果你换了 R2 的公开访问域名（比如从 `pub-xxx.r2.dev` 换成自己绑的域名），改完 `.env` 之后必须：

```bash
docker compose up -d --build   # 一定要带 --build，只 restart 不会重新读取新域名
```

只 `docker compose restart` 是不会生效的，因为白名单已经在上一次构建时焊死在产物里了，得重新构建才能刷新。

## 已知坑：Turnstile 配了，注册页人机验证还是过不去

跟上面 R2 域名那个坑是同一类问题：`NEXT_PUBLIC_TURNSTILE_SITE_KEY` 也是 `NEXT_PUBLIC_` 开头的变量，同样是构建时焊死进前端 JS 包的，不是运行时读的。这个项目已经把它加进了 `docker-compose.yml` 的 `build.args` 和 `Dockerfile` 的 `ARG`/`ENV`，正常 `docker compose up -d --build` 不会有事。

**但要记住**：以后如果重新生成/更换了 Turnstile 的 Site Key（`TURNSTILE_SECRET_KEY` 不受影响，那个是运行时读的），改完 `.env` 之后同样必须：

```bash
docker compose up -d --build   # 一定要带 --build
```

否则的现象是：注册页看起来一切正常（甚至验证框都不显示），但提交时后端一直报"人机验证未通过"——因为前端拿到的 `siteKey` 还是旧构建里焊死的值（或者压根是 `undefined`，组件直接不渲染），永远交不出一个有效 token 给后端校验。

## 后台导航

所有后台页面（图集管理、分类管理、外观设置）现在共用一个顶部导航栏，随时可以点回其他页面，不用再靠浏览器"后退"或者记 URL。导航栏在 `app/monkey/(protected)/layout.tsx` 里，登录页（`/monkey/login`）不在这个分组下，不会带上这个导航栏。

导航栏右侧有两个东西：
- **查看前台**：新标签页打开首页，方便发布完图集直接跳过去看效果，不会影响后台这边的状态
- **退出登录**：清掉登录 cookie 跳回登录页（之前这个功能一直没做，现在补上了）

图集列表里已发布的图集也加了个"预览"链接，同样是新标签页打开对应的图集详情页。

## 后续可以扩展的方向

- 图片量大了之后，可以引入 Redis 做浏览量计数缓冲、热门图集查询缓存（当前是直接读写 Postgres）
- 缩略图目前是浏览器端用 canvas 生成，如果要支持更精细的多档尺寸（比如 WebP + AVIF 双格式），可以换成服务端用 sharp 处理，配合队列异步执行
- 目前只有单个管理员表，如果要多人协作管理，可以加角色字段
