-- AlterTable
ALTER TABLE "NavLink" ALTER COLUMN "url" DROP NOT NULL,
ADD COLUMN     "categoryId" TEXT;

-- CreateIndex
CREATE INDEX "NavLink_categoryId_idx" ON "NavLink"("categoryId");

-- AddForeignKey
ALTER TABLE "NavLink" ADD CONSTRAINT "NavLink_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "Category"("id") ON DELETE SET NULL ON UPDATE CASCADE;
