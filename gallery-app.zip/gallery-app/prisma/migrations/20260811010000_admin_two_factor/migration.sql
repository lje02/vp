-- 超级管理员的两步验证（TOTP）。只对 SUPER_ADMIN 生效（见 lib/two-factor.ts 和
-- app/api/monkey/login/route.ts 里的判断），子管理员账号不受影响。
--
-- twoFactorSecret：TOTP 密钥，不是明文存的——用 AUTH_SECRET 派生出的 key 做 AES-256-GCM
-- 加密后再存这一列（密文的 base64），数据库被拖库也不会直接拿到能生成验证码的密钥。
-- 没绑定 / 绑定过程中还没确认完成时是 NULL。
--
-- twoFactorEnabled：真正生效的开关。绑定分两步（先生成密钥给你扫码，扫码后验证一次
-- 6 位验证码才算绑定成功），这一列只在验证通过后才会置 true，避免"扫了码但没验证成功"
-- 却被当成已经开启，导致下次登录被要求输一个从没跑通过的验证码。
--
-- twoFactorBackupCodes：一次性备用码，JSON 字符串数组，每个存的是 bcrypt 哈希（重开时随时看
-- app/api/monkey/account/password/route.ts 的哈希手法就是同一套思路）。手机丢了/验证器
-- 卸载了的时候，用备用码代替 6 位验证码登录，用掉一个就从数组里移除那一个。
ALTER TABLE "AdminUser" ADD COLUMN "twoFactorSecret" TEXT;
ALTER TABLE "AdminUser" ADD COLUMN "twoFactorEnabled" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "AdminUser" ADD COLUMN "twoFactorBackupCodes" TEXT;
