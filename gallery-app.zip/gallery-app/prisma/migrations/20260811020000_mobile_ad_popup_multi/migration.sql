-- 移动端弹窗广告从 1 个扩到 3 个（同一个弹窗里堆叠展示，见 MobileAdPopup.tsx）。
-- 把原来那一列改名当第 1 个位，已经保存过的内容不会丢；再加两个新位，默认空，
-- 跟桌面 adCode1~5 的"留空则不展示"是同一套约定。
ALTER TABLE "SiteSetting" RENAME COLUMN "mobileAdCode" TO "mobileAdCode1";
ALTER TABLE "SiteSetting" ADD COLUMN "mobileAdCode2" TEXT NOT NULL DEFAULT '';
ALTER TABLE "SiteSetting" ADD COLUMN "mobileAdCode3" TEXT NOT NULL DEFAULT '';
