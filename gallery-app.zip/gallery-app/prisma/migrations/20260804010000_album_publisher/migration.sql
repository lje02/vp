-- 记录"谁把图集发布的"，用来在封面卡片上打发布者角标。
-- 现有图集这一列全部是 NULL——升级前没有记录这个信息，没法回溯，这些图集
-- 就是没有角标，不是 bug，等下次有人编辑/重新发布这些图集之后自然会补上。

ALTER TABLE "Album" ADD COLUMN "publishedById" TEXT;

ALTER TABLE "Album"
  ADD CONSTRAINT "Album_publishedById_fkey"
  FOREIGN KEY ("publishedById") REFERENCES "AdminUser"("id")
  ON DELETE SET NULL ON UPDATE CASCADE;

CREATE INDEX "Album_publishedById_idx" ON "Album"("publishedById");
