-- 把标签从 Album.tags（String[]）改造成真正的关系模型：
-- 独立的 "Tag" 表 + Prisma 隐式多对多关系表 "_AlbumToTag"。
-- 之前重命名/合并标签要把所有相关图集的 tags 数组整个重写一遍，
-- 统计每个标签下有多少图集也得靠 unnest() 原生 SQL；
-- 换成关系表之后，重命名只需要改 Tag 自己的一行，统计交给 Prisma 的关系计数，
-- 合并操作也有了真正的唯一性保证（数据库层面不会出现同一图集挂两个同名标签）。
--
-- 这个迁移分三段：
--   1) 建表、建索引、建外键（结构变更）
--   2) 把现有 Album.tags 数组里的数据灌进新表（数据迁移，不会丢数据）
--   3) 删掉旧的 tags 列（连带的 GIN 索引 Album_tags_gin_idx 会被 Postgres 自动一起删掉）

-- 1) 结构变更 -----------------------------------------------------------

CREATE TABLE "Tag" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Tag_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "Tag_name_key" ON "Tag"("name");

-- Prisma 隐式多对多关系表的标准结构：A 是字母序较前的模型（Album），B 是较后的（Tag）
CREATE TABLE "_AlbumToTag" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

CREATE UNIQUE INDEX "_AlbumToTag_AB_unique" ON "_AlbumToTag"("A", "B");
CREATE INDEX "_AlbumToTag_B_index" ON "_AlbumToTag"("B");

ALTER TABLE "_AlbumToTag" ADD CONSTRAINT "_AlbumToTag_A_fkey"
    FOREIGN KEY ("A") REFERENCES "Album"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "_AlbumToTag" ADD CONSTRAINT "_AlbumToTag_B_fkey"
    FOREIGN KEY ("B") REFERENCES "Tag"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- 2) 数据迁移 -------------------------------------------------------------
-- id 用 md5(random 拼时间戳) 生成一个不重复的 32 位十六进制字符串即可，
-- 不需要跟 Prisma Client 那边 @default(cuid()) 生成的格式长得一样——
-- 这个字段只是内部用来做关联的不透明字符串，不会被拿去做格式校验或展示。

-- 2a) 从现有 Album.tags 数组里去重，建出所有 Tag 行
INSERT INTO "Tag" ("id", "name", "createdAt")
SELECT md5(random()::text || clock_timestamp()::text || t), t, CURRENT_TIMESTAMP
FROM (SELECT DISTINCT unnest("tags") AS t FROM "Album") AS distinct_tags;

-- 2b) 按原来的数组内容，把每个图集跟对应的 Tag 关联起来
INSERT INTO "_AlbumToTag" ("A", "B")
SELECT a."id", tag."id"
FROM "Album" a
CROSS JOIN LATERAL unnest(a."tags") AS album_tag
JOIN "Tag" tag ON tag."name" = album_tag;

-- 3) 删掉旧列 --------------------------------------------------------------
ALTER TABLE "Album" DROP COLUMN "tags";
