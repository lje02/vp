-- 多管理员 + 权限分级：超级管理员（SUPER_ADMIN）能创建/管理其他管理员，
-- 普通管理员（ADMIN）按内容/用户/设置三个模块分别授权。
--
-- 关键点：role 默认值是 'ADMIN'（给"以后新建的"账号用的默认值），但升级前
-- 数据库里已经存在的账号（在这次升级之前，语义上就是唯一的最高权限账号）
-- 必须回填成 SUPER_ADMIN，而不是按默认值变成权限最低的 ADMIN——不然升级
-- 上线的瞬间，原来能登录管理一切的账号会突然失去大部分权限，相当于把自己
-- 锁在后台大门外面。

CREATE TYPE "AdminRole" AS ENUM ('SUPER_ADMIN', 'ADMIN');

ALTER TABLE "AdminUser" ADD COLUMN "role" "AdminRole" NOT NULL DEFAULT 'ADMIN';
ALTER TABLE "AdminUser" ADD COLUMN "canManageContent" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "AdminUser" ADD COLUMN "canManageUsers" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "AdminUser" ADD COLUMN "canManageSettings" BOOLEAN NOT NULL DEFAULT false;

-- 回填：升级前已存在的账号全部设成超级管理员
UPDATE "AdminUser" SET "role" = 'SUPER_ADMIN';
