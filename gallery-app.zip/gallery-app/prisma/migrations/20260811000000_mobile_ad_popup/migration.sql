-- 移动端广告位：之前移动端完全不展示广告（AdSidebar 在 lg 断点以下直接不渲染）。
-- 现在给移动端单独加一个弹窗广告位，跟桌面端的 adCode1~5 是各自独立的一份代码，
-- 不复用桌面那 5 个——桌面是侧栏里的展示广告，移动端是弹窗，素材尺寸和交互都不一样，
-- 混用同一份代码大概率不合适。留空则前台不弹窗，跟 adCode1~5 的兜底逻辑一致。

ALTER TABLE "SiteSetting" ADD COLUMN "mobileAdCode" TEXT NOT NULL DEFAULT '';
