import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import {
  createSession,
  getPendingTwoFactorUserId,
  clearPendingTwoFactorSession,
} from '@/lib/auth';
import { verifyTotpToken, consumeBackupCode } from '@/lib/two-factor';
import { isRateLimited } from '@/lib/rate-limit';
import { getClientIp } from '@/lib/client-ip';

const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

const IP_RATE_LIMIT_WINDOW_MS = 60 * 1000;
const IP_RATE_LIMIT_MAX = 10; // 跟 login/route.ts 的密码那一步用一样的阈值，同一类"猜口令"场景

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  if (await isRateLimited('login2faratelimit', ip, { windowMs: IP_RATE_LIMIT_WINDOW_MS, max: IP_RATE_LIMIT_MAX })) {
    return NextResponse.json({ error: '验证请求过于频繁，请稍后再试' }, { status: 429 });
  }

  // 这一步的身份来自密码验证通过后签发的短期令牌（createPendingTwoFactorSession），
  // 不是从请求体里的 email/userId 之类的字段来——那样任何人拿别人的邮箱就能对着这个接口
  // 硬撞验证码，而这里必须先过了密码这一关才能拿到这枚令牌
  const userId = await getPendingTwoFactorUserId();
  if (!userId) {
    return NextResponse.json({ error: '登录状态已过期，请重新输入邮箱和密码' }, { status: 401 });
  }

  const { code } = await req.json().catch(() => ({ code: '' }));
  const candidate = typeof code === 'string' ? code.trim() : '';
  if (!candidate) {
    return NextResponse.json({ error: '请输入验证码' }, { status: 400 });
  }

  const user = await prisma.adminUser.findUnique({ where: { id: userId } });
  // 账号被删了，或者两步验证在这次半登录期间被关掉了（比如另一个会话刚关闭了它）——
  // 都不该再让这枚待验证令牌继续生效
  if (!user || user.role !== 'SUPER_ADMIN' || !user.twoFactorEnabled || !user.twoFactorSecret) {
    await clearPendingTwoFactorSession();
    return NextResponse.json({ error: '登录状态已失效，请重新登录' }, { status: 401 });
  }

  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const remainingMin = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    return NextResponse.json(
      { error: `登录失败次数过多，账号已锁定，请 ${remainingMin} 分钟后再试` },
      { status: 429 },
    );
  }

  // 先按 6 位 TOTP 验证码校验，不匹配再当备用码试一次——两种格式基本不会互相误判
  // （TOTP 固定 6 位数字，备用码是 10 位），顺序上先试更常用的那种，减少一次 bcrypt 开销
  const totpValid = verifyTotpToken(user.twoFactorSecret, candidate, user.email);
  let backupCodeConsumed: string | null = null;
  if (!totpValid) {
    const result = await consumeBackupCode(user.twoFactorBackupCodes, candidate);
    if (result) backupCodeConsumed = result.remaining;
  }

  if (!totpValid && !backupCodeConsumed) {
    const failedAttempts = user.failedAttempts + 1;
    const shouldLock = failedAttempts >= MAX_ATTEMPTS;

    await prisma.adminUser.update({
      where: { id: user.id },
      data: {
        failedAttempts: shouldLock ? 0 : failedAttempts,
        lockedUntil: shouldLock ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
      },
    });

    if (shouldLock) {
      await clearPendingTwoFactorSession();
      return NextResponse.json(
        { error: `连续输错 ${MAX_ATTEMPTS} 次，账号已锁定 ${LOCK_MINUTES} 分钟，请重新登录` },
        { status: 429 },
      );
    }

    return NextResponse.json(
      { error: `验证码不对（还可以尝试 ${MAX_ATTEMPTS - failedAttempts} 次）` },
      { status: 401 },
    );
  }

  await prisma.adminUser.update({
    where: { id: user.id },
    data: {
      failedAttempts: 0,
      lockedUntil: null,
      // 只有真的用掉了一个备用码才需要更新这一列；TOTP 验证通过不用碰它
      ...(backupCodeConsumed ? { twoFactorBackupCodes: backupCodeConsumed } : {}),
    },
  });

  await clearPendingTwoFactorSession();
  await createSession(user.id);
  return NextResponse.json({ ok: true, usedBackupCode: backupCodeConsumed !== null });
}
