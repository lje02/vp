import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { invalidateCategoryTreeCache } from '@/lib/categories';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requirePermissionApi } from '@/lib/auth';

// 删除分类时不删除图集，只是把图集的 categoryId 置空（数据库层 onDelete: SetNull 已处理）
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id } = await params;
  await prisma.category.delete({ where: { id } });
  await invalidateCategoryTreeCache();
  revalidatePath('/');
  await broadcastCacheInvalidation([{ path: '/' }]);
  return NextResponse.json({ ok: true });
}
