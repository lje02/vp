import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';
import { validatePasswordStrength } from '@/lib/password';

// 改子管理员的模块权限，顺便支持超级管理员帮子管理员重置密码（body 里带
// newPassword 才会改密码，不带就只改权限）。
//
// 角色（role）不允许通过这个接口改——升/降级超级管理员只能走命令行
// prisma/create-admin.ts，理由见该文件里的注释：一旦允许在 UI 上把某个账号
// 提升成 SUPER_ADMIN，就得同时处理"这个新超级管理员反过来能不能把创建它的
// 那个超级管理员降级/删除"之类的一整套权限链条问题，对这个项目的实际使用
// 场景（团队规模很小）来说完全没必要，故意不做。
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const target = await prisma.adminUser.findUnique({ where: { id } });
  if (!target) {
    return NextResponse.json({ error: '管理员不存在' }, { status: 404 });
  }
  if (target.role === 'SUPER_ADMIN') {
    return NextResponse.json({ error: '超级管理员的权限/密码不能在这里改' }, { status: 400 });
  }

  const body = await req.json().catch(() => null);
  const data: Record<string, unknown> = {};

  if (body && typeof body === 'object') {
    if ('canManageContent' in body) data.canManageContent = body.canManageContent === true;
    if ('canManageUsers' in body) data.canManageUsers = body.canManageUsers === true;
    if ('canManageSettings' in body) data.canManageSettings = body.canManageSettings === true;

    if (typeof body.newPassword === 'string' && body.newPassword.length > 0) {
      const strength = validatePasswordStrength(body.newPassword);
      if (!strength.valid) {
        return NextResponse.json({ error: strength.message }, { status: 400 });
      }
      data.passwordHash = await bcrypt.hash(body.newPassword, 10);
      // 超级管理员帮忙重置密码，顺便解掉可能存在的失败次数锁定，
      // 不然对方拿着新密码登录还是会先撞上锁定期
      data.failedAttempts = 0;
      data.lockedUntil = null;
    }
  }

  const updated = await prisma.adminUser.update({
    where: { id },
    data,
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
    },
  });

  return NextResponse.json(updated);
}

// 删除子管理员。超级管理员账号（role === 'SUPER_ADMIN'）一律不能通过这个
// 接口删除——包括操作者自己：这样"最后一个超级管理员"这种边界情况根本
// 不会发生，不用专门写检测逻辑。真要注销一个超级管理员账号，去数据库
// 手动处理，这种操作理应比点一个按钮更慎重。
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const { id } = await params;
  const target = await prisma.adminUser.findUnique({ where: { id }, select: { id: true, role: true } });
  if (!target) {
    return NextResponse.json({ ok: true }); // 已经不存在，幂等
  }
  if (target.role === 'SUPER_ADMIN') {
    return NextResponse.json({ error: '超级管理员账号不能通过后台删除' }, { status: 400 });
  }

  await prisma.adminUser.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
