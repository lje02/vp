import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { requireAdminApi } from '@/lib/auth';
import { validatePasswordStrength } from '@/lib/password';

// 自助改密码，任何登录状态的管理员（不管超级管理员还是子管理员）都能用，
// 不需要额外权限——这是"改自己的账号"，跟三个业务模块的权限授权是两回事。
export async function PATCH(req: NextRequest) {
  const auth = await requireAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const currentPassword = typeof body?.currentPassword === 'string' ? body.currentPassword : '';
  const newPassword = typeof body?.newPassword === 'string' ? body.newPassword : '';

  if (!currentPassword || !newPassword) {
    return NextResponse.json({ error: '请填写当前密码和新密码' }, { status: 400 });
  }

  const strength = validatePasswordStrength(newPassword);
  if (!strength.valid) {
    return NextResponse.json({ error: strength.message }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { id: auth.session.userId } });
  if (!admin) {
    return NextResponse.json({ error: '账号不存在' }, { status: 401 });
  }

  const valid = await bcrypt.compare(currentPassword, admin.passwordHash);
  if (!valid) {
    return NextResponse.json({ error: '当前密码不对' }, { status: 401 });
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { passwordHash },
  });

  return NextResponse.json({ ok: true });
}
