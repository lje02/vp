import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import QRCode from 'qrcode';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';
import { beginTotpEnrollment } from '@/lib/two-factor';

// 只有超级管理员账号能开两步验证（见迁移文件里的说明：权限最高、影响最大，
// 子管理员暂不适用），requireSuperAdminApi 已经把这层判断做掉了，这里不用再重复。
export async function POST(req: NextRequest) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!password) {
    return NextResponse.json({ error: '请输入当前密码' }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { id: auth.session.userId } });
  if (!admin) {
    return NextResponse.json({ error: '账号不存在' }, { status: 401 });
  }

  // 生成新密钥之前先验证密码——如果只靠"当前 session 有效"就允许绑定，
  // 一个偷到 cookie 但不知道密码的人也能把自己的验证器绑上去，之后就算密码被改掉
  // 依然能靠自己那份验证码长期登录。要求密码这一步能把这条路堵上。
  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) {
    return NextResponse.json({ error: '当前密码不对' }, { status: 401 });
  }

  if (admin.twoFactorEnabled) {
    return NextResponse.json({ error: '两步验证已经是开启状态，如需更换请先关闭再重新绑定' }, { status: 400 });
  }

  const { encryptedSecret, otpauthUrl, base32Secret } = beginTotpEnrollment(admin.email);

  // 这一步只是把密钥存起来，enabled 仍然是 false——真正生效要等
  // /api/monkey/account/two-factor/confirm 用一个当下有效的验证码验证通过
  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { twoFactorSecret: encryptedSecret },
  });

  // 二维码在服务端生成好直接返回 data URL——otpauth:// URI 本身就包含密钥明文，
  // 没必要额外让前端再引入一份 qrcode 库、在浏览器里重新编码一次
  const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl, { margin: 1, width: 240 });

  return NextResponse.json({ qrCodeDataUrl, base32Secret });
}
