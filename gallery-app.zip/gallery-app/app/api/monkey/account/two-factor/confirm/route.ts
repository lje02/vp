import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';
import { verifyTotpToken, generateBackupCodes } from '@/lib/two-factor';

export async function POST(req: NextRequest) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const code = typeof body?.code === 'string' ? body.code.trim() : '';
  if (!code) {
    return NextResponse.json({ error: '请输入验证器 App 里显示的 6 位验证码' }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { id: auth.session.userId } });
  if (!admin?.twoFactorSecret) {
    return NextResponse.json({ error: '还没有开始绑定流程，请先生成二维码' }, { status: 400 });
  }
  if (admin.twoFactorEnabled) {
    return NextResponse.json({ error: '两步验证已经是开启状态' }, { status: 400 });
  }

  if (!verifyTotpToken(admin.twoFactorSecret, code, admin.email)) {
    return NextResponse.json({ error: '验证码不对，确认一下验证器 App 里显示的是不是这一个' }, { status: 401 });
  }

  const { plain, hashed } = await generateBackupCodes();

  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { twoFactorEnabled: true, twoFactorBackupCodes: hashed },
  });

  // 备用码明文只有这一次机会返回，之后数据库里只剩 bcrypt 哈希，连管理员自己都看不到原文了
  return NextResponse.json({ ok: true, backupCodes: plain });
}
