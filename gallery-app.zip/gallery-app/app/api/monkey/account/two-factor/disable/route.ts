import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!password) {
    return NextResponse.json({ error: '请输入当前密码' }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { id: auth.session.userId } });
  if (!admin) {
    return NextResponse.json({ error: '账号不存在' }, { status: 401 });
  }

  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) {
    return NextResponse.json({ error: '当前密码不对' }, { status: 401 });
  }

  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { twoFactorEnabled: false, twoFactorSecret: null, twoFactorBackupCodes: null },
  });

  return NextResponse.json({ ok: true });
}
