import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { requireSuperAdminApi } from '@/lib/auth';
import { generateBackupCodes } from '@/lib/two-factor';

// 重新生成一批备用码——之前那批（不管用没用完）会整批作废，避免旧码继续留着当风险，
// 这跟"忘记密码找回后旧密码立刻失效"是同一个思路。
export async function POST(req: NextRequest) {
  const auth = await requireSuperAdminApi();
  if ('response' in auth) return auth.response;

  const body = await req.json().catch(() => null);
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!password) {
    return NextResponse.json({ error: '请输入当前密码' }, { status: 400 });
  }

  const admin = await prisma.adminUser.findUnique({ where: { id: auth.session.userId } });
  if (!admin?.twoFactorEnabled) {
    return NextResponse.json({ error: '还没有开启两步验证' }, { status: 400 });
  }

  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) {
    return NextResponse.json({ error: '当前密码不对' }, { status: 401 });
  }

  const { plain, hashed } = await generateBackupCodes();
  await prisma.adminUser.update({ where: { id: admin.id }, data: { twoFactorBackupCodes: hashed } });

  return NextResponse.json({ backupCodes: plain });
}
