import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/storage';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requirePermissionApi } from '@/lib/auth';

// body: { ids: string[], action: 'delete' | 'setCategory' | 'setVisibility' | 'setFeatured', value?: unknown }
//
// 后台列表页多选之后的批量操作统一走这一个接口，不是每种操作单独开一条路由——
// 这几种操作共享同一套"取出受影响的图集 → 执行 → 刷新缓存"流程，拆开的话每个
// route 都要重复写一遍这段收尾逻辑。action 用字符串枚举而不是拆成多个 HTTP method，
// 是因为这里的"资源"是一批图集的某个属性变更，不是单一资源上的 CRUD，硬套 REST
// 动词反而别扭。
export async function POST(req: NextRequest) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { ids, action, value } = await req.json().catch(() => ({}));

  if (!Array.isArray(ids) || ids.length === 0 || typeof ids[0] !== 'string') {
    return NextResponse.json({ error: '缺少要操作的图集 id 列表' }, { status: 400 });
  }
  // 批量操作影响面比单个操作大得多，给个上限，避免一次性传几千个 id 进来
  // （正常使用场景下后台列表一页最多几十条，选中的数量不会超过这个量级）
  if (ids.length > 200) {
    return NextResponse.json({ error: '一次最多操作 200 个图集' }, { status: 400 });
  }

  const albums = await prisma.album.findMany({
    where: { id: { in: ids } },
    select: { id: true, slug: true, photos: { select: { r2Key: true, thumbKey: true } } },
  });
  if (albums.length === 0) {
    return NextResponse.json({ error: '没有找到对应的图集' }, { status: 404 });
  }

  let r2CleanupFailed = 0;

  switch (action) {
    case 'delete': {
      await prisma.album.deleteMany({ where: { id: { in: albums.map((a) => a.id) } } });
      await prisma.tag.deleteMany({ where: { albums: { none: {} } } });

      const results = await Promise.allSettled(
        albums.flatMap((a) => a.photos.flatMap((p) => [deleteObject(p.r2Key), deleteObject(p.thumbKey)])),
      );
      r2CleanupFailed = results.filter((r) => r.status === 'rejected').length;
      break;
    }
    case 'setCategory': {
      const categoryId = typeof value === 'string' && value ? value : null;
      await prisma.album.updateMany({ where: { id: { in: albums.map((a) => a.id) } }, data: { categoryId } });
      break;
    }
    case 'setVisibility': {
      if (value !== 'PUBLIC' && value !== 'PRIVATE') {
        return NextResponse.json({ error: 'value 必须是 PUBLIC 或 PRIVATE' }, { status: 400 });
      }
      await prisma.album.updateMany({ where: { id: { in: albums.map((a) => a.id) } }, data: { visibility: value } });
      break;
    }
    case 'setFeatured': {
      await prisma.album.updateMany({
        where: { id: { in: albums.map((a) => a.id) } },
        data: { featured: !!value },
      });
      break;
    }
    default:
      return NextResponse.json({ error: `不支持的操作：${action}` }, { status: 400 });
  }

  revalidatePath('/');
  const paths = [{ path: '/' }, ...albums.map((a) => ({ path: `/${a.slug}` }))];
  for (const a of albums) revalidatePath(`/${a.slug}`);
  await broadcastCacheInvalidation(paths);

  return NextResponse.json({ ok: true, affected: albums.length, r2CleanupFailed });
}
