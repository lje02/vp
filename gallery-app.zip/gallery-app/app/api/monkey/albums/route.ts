import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { toSlug, RESERVED_SLUGS, findConflictingTag } from '@/lib/slug';
import { toTitlePinyin } from '@/lib/pinyin';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requirePermissionApi } from '@/lib/auth';

// GET: 后台图集列表（含草稿）
export async function GET() {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const albums = await prisma.album.findMany({
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { photos: true } } },
  });
  return NextResponse.json(albums);
}

// POST: 创建图集
// body: { title, description, tags: string[], categoryId?: string, coverIndex?: number,
//         photos: [{ r2Key, thumbKey, width, height, altText, ...EXIF字段 }], visibility,
//         featured?: boolean, scheduledPublishAt?: string | null }
//
// scheduledPublishAt 有值时，图集直接建成 DRAFT，不管前端传没传 status/visibility——
// 定时发布的图集在到点之前本来就不该出现在任何公开列表里，等 scripts/publish-scheduled.ts
// 到点自动转 PUBLISHED。没传 scheduledPublishAt 就是原来的行为：创建即发布。
export async function POST(req: NextRequest) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const body = await req.json();
  const {
    title,
    description,
    tags = [],
    categoryId,
    coverIndex = 0,
    photos = [],
    visibility,
    featured,
    scheduledPublishAt,
  } = body;

  if (!title || photos.length === 0) {
    return NextResponse.json({ error: '标题和至少一张图片是必须的' }, { status: 400 });
  }

  const baseSlug = toSlug(title);
  let slug = baseSlug;
  let counter = 1;
  while (RESERVED_SLUGS.has(slug) || (await prisma.album.findUnique({ where: { slug } }))) {
    slug = `${baseSlug}-${counter++}`;
  }

  const tagConflict = await findConflictingTag(tags);
  if (tagConflict) {
    return NextResponse.json(
      { error: `标签名"${tagConflict}"和站点固定路径或已有图集地址重名，换一个名字` },
      { status: 400 },
    );
  }

  const cover = photos[coverIndex] || photos[0];
  const isScheduled = typeof scheduledPublishAt === 'string' && scheduledPublishAt.length > 0;

  const album = await prisma.album.create({
    data: {
      title,
      titlePinyin: toTitlePinyin(title),
      slug,
      description,
      tags: {
        connectOrCreate: Array.from(new Set(tags as string[])).map((name) => ({
          where: { name },
          create: { name },
        })),
      },
      categoryId: categoryId || null,
      coverKey: cover?.thumbKey,
      coverBlurDataURL: cover?.blurDataURL || null,
      status: isScheduled ? 'DRAFT' : 'PUBLISHED',
      visibility: visibility === 'PRIVATE' ? 'PRIVATE' : 'PUBLIC',
      featured: !!featured,
      scheduledPublishAt: isScheduled ? new Date(scheduledPublishAt) : null,
      publishedAt: isScheduled ? null : new Date(),
      // 不管是立即发布还是设置定时发布，创建这个图集的人都记成发布者——
      // 定时发布只是"发布"这个动作被延迟执行，决定要发布的人没变
      publishedById: auth.session.userId,
      photos: {
        create: photos.map((p: any, i: number) => ({
          r2Key: p.r2Key,
          thumbKey: p.thumbKey,
          width: p.width,
          height: p.height,
          altText: p.altText || '',
          blurDataURL: p.blurDataURL || null,
          sortOrder: i,
          takenAt: p.takenAt ? new Date(p.takenAt) : null,
          cameraMake: p.cameraMake || null,
          cameraModel: p.cameraModel || null,
          lensModel: p.lensModel || null,
          focalLength: p.focalLength || null,
          aperture: p.aperture || null,
          shutterSpeed: p.shutterSpeed || null,
          iso: typeof p.iso === 'number' ? p.iso : null,
        })),
      },
    },
  });

  // 定时发布的图集在到点之前不该出现在任何公开页面/缓存里，不用重新生成缓存
  if (!isScheduled) {
    // 重新生成首页和图集详情页的静态缓存（图集详情页是扁平路径 /slug，不是 /albums/slug）
    revalidatePath('/');
    revalidatePath(`/${slug}`);
    await broadcastCacheInvalidation([{ path: '/' }, { path: `/${slug}` }]);
  }

  return NextResponse.json(album, { status: 201 });
}
