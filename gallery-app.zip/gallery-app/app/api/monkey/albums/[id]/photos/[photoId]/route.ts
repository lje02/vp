import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { deleteObject } from '@/lib/storage';
import { revalidatePath } from 'next/cache';
import { broadcastCacheInvalidation } from '@/lib/cache-broadcast';
import { requirePermissionApi } from '@/lib/auth';

// DELETE: 删除图集里的单张图片（同时清理 R2 上的原图+缩略图）
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; photoId: string }> },
) {
  const auth = await requirePermissionApi('content');
  if ('response' in auth) return auth.response;

  const { id, photoId } = await params;

  const photo = await prisma.photo.findUnique({ where: { id: photoId } });
  if (!photo || photo.albumId !== id) {
    return NextResponse.json({ error: '图片不存在' }, { status: 404 });
  }

  const album = await prisma.album.findUnique({ where: { id }, select: { slug: true, coverKey: true } });
  if (!album) {
    return NextResponse.json({ error: '图集不存在' }, { status: 404 });
  }

  // 先删数据库记录，再清理 R2，跟删整个图集的顺序保持一致：
  // 最坏情况是 R2 上留几个孤儿文件，好过前台裂图
  await prisma.photo.delete({ where: { id: photoId } });

  const results = await Promise.allSettled([deleteObject(photo.r2Key), deleteObject(photo.thumbKey)]);
  const failedCount = results.filter((r) => r.status === 'rejected').length;
  if (failedCount > 0) {
    console.error(`删除图集 ${album.slug} 里的一张图片时，有 ${failedCount} 个 R2 文件清理失败，需要手动检查`);
  }

  // 删的正好是当前封面，换成剩下第一张；一张都不剩就置空
  if (album.coverKey === photo.thumbKey) {
    const next = await prisma.photo.findFirst({
      where: { albumId: id },
      orderBy: { sortOrder: 'asc' },
      select: { thumbKey: true, blurDataURL: true },
    });
    await prisma.album.update({
      where: { id },
      data: { coverKey: next?.thumbKey ?? null, coverBlurDataURL: next?.blurDataURL ?? null },
    });
  }

  revalidatePath('/');
  revalidatePath(`/${album.slug}`);
  await broadcastCacheInvalidation([{ path: '/' }, { path: `/${album.slug}` }]);

  return NextResponse.json({ ok: true, r2CleanupFailed: failedCount });
}
