import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { createUserSession } from '@/lib/user-auth';
import { isRateLimited } from '@/lib/rate-limit';
import { getClientIp } from '@/lib/client-ip';
import { validatePasswordStrength } from '@/lib/password';
import { verifyTurnstile } from '@/lib/turnstile';

// 注册要防的是"批量刷号"，跟登录接口防的"暴力试密码"是不同的威胁模型，窗口和阈值也不一样：
// 登录按分钟算（挡短时间内高频试密码），注册按小时算——正常人一小时内不会注册好几个号，
// 超过了大概率是脚本在批量开号
const IP_RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000;
const IP_RATE_LIMIT_MAX = 3;

// 表单从渲染到提交，真人至少要看一眼、点几下、打字，不可能在这么短时间内完成——
// 脚本直接构造请求提交会踩到这条线，挡的是"懒得模拟等待"的业余脚本，
// 前端会把表单渲染时的时间戳传回来，这里只是做个减法比较，不依赖任何外部服务
const MIN_SUBMIT_MS = 1500;

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  if (await isRateLimited('registerratelimit', ip, { windowMs: IP_RATE_LIMIT_WINDOW_MS, max: IP_RATE_LIMIT_MAX })) {
    return NextResponse.json({ error: '注册请求过于频繁，请稍后再试' }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object') {
    return NextResponse.json({ error: '请求格式不对' }, { status: 400 });
  }
  const { email, password, turnstileToken, website, formRenderedAt } = body as Record<string, unknown>;

  // 蜜罐字段：前端会用 CSS 把这个输入框藏起来，真人看不到也不会填，
  // 很多简单脚本会无脑把所有 <input> 都填一遍。一旦有值，装作注册成功，
  // 不告诉对方是被识破的，免得对方针对性调整脚本再来一次
  if (typeof website === 'string' && website.trim() !== '') {
    return NextResponse.json({ ok: true });
  }

  if (typeof formRenderedAt === 'number' && Date.now() - formRenderedAt < MIN_SUBMIT_MS) {
    return NextResponse.json({ ok: true });
  }

  if (!(await verifyTurnstile(turnstileToken, ip))) {
    return NextResponse.json({ error: '人机验证未通过，刷新页面重试' }, { status: 400 });
  }

  if (typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: '请输入有效的邮箱地址' }, { status: 400 });
  }

  if (typeof password !== 'string') {
    return NextResponse.json({ error: '请输入密码' }, { status: 400 });
  }
  const strength = validatePasswordStrength(password);
  if (!strength.valid) {
    return NextResponse.json({ error: strength.message }, { status: 400 });
  }

  const normalizedEmail = email.trim().toLowerCase();

  const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
  if (existing) {
    // 注册页跟登录页不一样：登录失败不能说"账号不存在"（防止被枚举），
    // 但注册页反过来必须告诉用户"你是不是已经注册过"，不然没法引导他去登录，
    // 这是正常做法，不算信息泄露
    return NextResponse.json({ error: '这个邮箱已经注册过了，直接登录就行' }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email: normalizedEmail, passwordHash } });

  await createUserSession(user.id);
  return NextResponse.json({ ok: true });
}
