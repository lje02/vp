import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/user-auth';

// 单独开一个接口给客户端异步查询登录状态，而不是在 layout.tsx 里直接读 cookie——
// 服务端组件里调用 cookies() 会让整个站点退出静态生成/ISR 缓存，这个成本太大了，
// 换成客户端挂载后异步查这一个小接口，页面主体渲染完全不受影响。
export async function GET() {
  const user = await getCurrentUser();
  return NextResponse.json({ email: user?.email ?? null });
}
