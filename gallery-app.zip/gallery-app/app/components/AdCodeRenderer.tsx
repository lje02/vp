'use client';

import { useEffect, useRef } from 'react';

// 直接用 dangerouslySetInnerHTML 插入一段含 <script> 的 HTML，浏览器不会执行
// 里面的脚本——这是所有框架通过 innerHTML 插入内容时的通病，不是 React 特有的
// 限制（原生 DOM API 本身就是这个行为）。广告联盟给的代码基本都依赖脚本执行
// （异步拉取真正的广告内容、上报曝光），所以这里手动把每个 <script> 节点摘出来，
// 用 document.createElement('script') 重新创建一份再塞回去，浏览器才会真的跑它。
//
// 每个广告位是独立的 AdCodeRenderer 实例，所以同一份代码在 5 个位置渲染，
// 会各自执行一次——如果广告代码本身没做"只能出现一次"的限制（大部分标准的
// 展示广告代码都支持同页面多实例），这是符合预期的，5 个广告位 = 5 次曝光请求。
export default function AdCodeRenderer({ code }: { code: string }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !code) return;

    container.innerHTML = code;

    // 摘出所有 <script> 标签，原地替换成能真正执行的版本
    const scripts = Array.from(container.querySelectorAll('script'));
    for (const oldScript of scripts) {
      const newScript = document.createElement('script');
      // 把原标签上的所有属性（src、async、data-* 之类）原样搬过去
      for (const attr of Array.from(oldScript.attributes)) {
        newScript.setAttribute(attr.name, attr.value);
      }
      // 内联脚本（没有 src，代码直接写在标签里）要把文本内容也搬过去，
      // 外链脚本（有 src）浏览器加载到 src 就够了，textContent 留空即可
      if (!oldScript.src) {
        newScript.textContent = oldScript.textContent;
      }
      oldScript.replaceWith(newScript);
    }

    // 卸载时清空，避免同一个容器复用时（比如切页面又切回来）内容重复叠加执行
    return () => {
      container.innerHTML = '';
    };
  }, [code]);

  return <div ref={containerRef} />;
}
