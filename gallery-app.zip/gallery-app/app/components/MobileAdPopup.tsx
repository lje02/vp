'use client';

import { useEffect, useState } from 'react';
import AdCodeRenderer from './AdCodeRenderer';

// 移动端专用的弹窗广告——桌面端有 AdSidebar 那个常驻侧栏，移动端屏幕太窄放不下，
// 之前是直接不展示（AdSidebar 在 lg 断点以下 return 的是 hidden）。这个组件走另一条路：
// 进站片刻后以弹窗形式露出一次，关闭后当次会话（这个浏览器标签页）不会再弹，
// 不会每切一个页面就弹一次，也不会挡住首屏内容的首次渲染。
//
// 放在根 layout 里全局挂载一份，所以不用关心具体是哪个页面——只要 mobileAdCode1~3
// 里有任意一个配置了内容，任何页面都可能触发这一次弹窗。
const SESSION_KEY = 'gallery-mobile-ad-dismissed';
const SHOW_DELAY_MS = 1200;

export default function MobileAdPopup({ codes }: { codes: string[] }) {
  const [visible, setVisible] = useState(false);
  // 3 个位里配置了内容的才展示，留空的直接跳过——不会在弹窗里留一块空白
  const activeCodes = codes.filter((c) => c?.trim());

  useEffect(() => {
    if (activeCodes.length === 0) return;

    // sessionStorage 而不是 localStorage：只想避免"同一次访问里反复弹"，
    // 不想做成"这个人这辈子只能看一次"——毕竟广告位是要恰好起到收益作用的。
    try {
      if (sessionStorage.getItem(SESSION_KEY)) return;
    } catch {
      // 隐私模式下 sessionStorage 可能不可用，读取失败就当没弹过，照常走弹窗逻辑，
      // 只是这种情况下没法"记住已关闭"，用户可能每次刷新都会看到，属于可接受的降级
    }

    const timer = setTimeout(() => setVisible(true), SHOW_DELAY_MS);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- activeCodes 是每次渲染都新建的数组，
    // 放进依赖数组会导致每次渲染都重新排一次定时器；实际只需要在"有没有内容"这个状态变化时触发
  }, [activeCodes.length]);

  function dismiss() {
    setVisible(false);
    try {
      sessionStorage.setItem(SESSION_KEY, '1');
    } catch {
      // 同上，存不了就算了，不影响这次关闭的即时效果
    }
  }

  if (activeCodes.length === 0 || !visible) return null;

  return (
    // lg:hidden：跟 AdSidebar 的断点保持一致，桌面端（有侧栏广告了）不会重复弹这个
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 lg:hidden"
      role="dialog"
      aria-modal="true"
      aria-label="广告"
      onClick={dismiss}
    >
      <div
        className="relative w-full max-w-sm rounded-lg border border-[var(--fg-10)] bg-[var(--bg-color)] p-3 shadow-xl"
        // 点弹窗内容本身不应该关掉弹窗（否则点到广告里的链接前会先被误关），
        // 只有点背景遮罩或叉号才关；这里拦住冒泡到外层 onClick 的事件
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-wide text-[var(--fg-40)]">广告</span>
          <button
            type="button"
            onClick={dismiss}
            aria-label="关闭广告"
            className="flex h-7 w-7 items-center justify-center rounded-full text-lg leading-none text-[var(--fg-50)] hover:bg-[var(--fg-10)] hover:text-[var(--text-color)]"
          >
            ×
          </button>
        </div>
        <div className="max-h-[70vh] space-y-3 overflow-auto">
          {/* 3 个位有内容的都在这一个弹窗里上下堆叠，中间用一条细线隔开，避免多个广告的
              边界糊在一起看不出是三份独立的内容 */}
          {activeCodes.map((c, i) => (
            <div key={i} className={i > 0 ? 'border-t border-[var(--fg-10)] pt-3' : ''}>
              <AdCodeRenderer code={c} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
