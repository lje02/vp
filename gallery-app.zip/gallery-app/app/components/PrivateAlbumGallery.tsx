'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import PhotoGallery, { type GalleryPhoto } from '@/app/components/PhotoGallery';

type State =
  | { status: 'loading' }
  | { status: 'unauthenticated' }
  | { status: 'forbidden' }
  | { status: 'error' }
  | { status: 'ok'; photos: GalleryPhoto[] };

// 私密相册的照片故意不在服务端渲染阶段就塞进页面（那个页面是 ISR 静态缓存，
// 所有访客共用同一份 HTML），挂载后单独请求 /api/albums/[slug]/photos，
// 那个接口每次都会实时判断"当前登录用户到底有没有被授权"，权限判断不会被缓存。
//
// 分享链接的 token（后台生成的免注册访问链接）同样不能从服务端 props 传进来——
// 这个组件被 export const revalidate = 3600 的 ISR 页面渲染，服务端读 URL 上的
// ?token= 会把某一次触发重新生成的请求里的 token 烘焙进所有访客共用的缓存 HTML。
// 改成直接读 window.location.search，这里不用 next/navigation 的 useSearchParams()——
// 那个 hook 要求外层包一层 <Suspense>，用原生 URLSearchParams 读一次性够用，不用为了
// 这一个值就给这个组件的使用处强加 Suspense 边界。
export default function PrivateAlbumGallery({ slug, albumTitle }: { slug: string; albumTitle: string }) {
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;

    const token = new URLSearchParams(window.location.search).get('token');
    const url = `/api/albums/${encodeURIComponent(slug)}/photos${token ? `?token=${encodeURIComponent(token)}` : ''}`;

    fetch(url)
      .then(async (res) => {
        if (cancelled) return;
        if (res.status === 401) {
          setState({ status: 'unauthenticated' });
          return;
        }
        if (res.status === 403) {
          setState({ status: 'forbidden' });
          return;
        }
        if (!res.ok) {
          setState({ status: 'error' });
          return;
        }
        const data = await res.json();
        const photos: GalleryPhoto[] = (data.photos ?? []).map(
          (p: {
            id: string;
            url: string;
            width: number;
            height: number;
            alt?: string;
            blurDataURL?: string;
            takenAt?: string;
            cameraMake?: string;
            cameraModel?: string;
            lensModel?: string;
            focalLength?: string;
            aperture?: string;
            shutterSpeed?: string;
            iso?: number;
          }) => ({
            ...p,
            alt: p.alt || albumTitle,
          }),
        );
        setState({ status: 'ok', photos });
      })
      .catch(() => {
        if (!cancelled) setState({ status: 'error' });
      });

    return () => {
      cancelled = true;
    };
  }, [slug, albumTitle]);

  if (state.status === 'loading') {
    return <div className="flex min-h-[40vh] items-center justify-center text-sm text-[var(--fg-40)]">加载中…</div>;
  }

  if (state.status === 'ok') {
    return <PhotoGallery photos={state.photos} />;
  }

  // unauthenticated / forbidden / error 都落到同一种锁定提示的视觉呈现，
  // 只是文案不一样——按之前定的原则，不透露照片张数，那也算内容的一部分
  const message =
    state.status === 'unauthenticated'
      ? '这个相册需要授权访问，请登录'
      : state.status === 'forbidden'
        ? '你还没有这个相册的访问权限，如需查看请联系管理员'
        : '加载失败，刷新页面重试';

  return (
    <div className="flex min-h-[40vh] flex-col items-center justify-center gap-4 rounded-lg border border-[var(--fg-10)] bg-[var(--fg-5)] px-6 py-16 text-center">
      <svg width="28" height="28" viewBox="0 0 18 18" fill="none" aria-hidden="true" className="text-[var(--fg-40)]">
        <rect x="4" y="8" width="10" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M6.5 8V5.5a2.5 2.5 0 0 1 5 0V8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
      <p className="text-sm text-[var(--fg-60)]">{message}</p>
      {state.status === 'unauthenticated' && (
        <Link
          href={`/login?next=${encodeURIComponent(`/${slug}`)}`}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-4 py-2 text-sm text-[var(--accent-contrast)]"
        >
          去登录
        </Link>
      )}
    </div>
  );
}
