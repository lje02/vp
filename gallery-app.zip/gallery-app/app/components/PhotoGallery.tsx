'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import Image from 'next/image';

export type GalleryPhoto = {
  id: string;
  url: string;
  width: number;
  height: number;
  alt: string;
  blurDataURL?: string;
  takenAt?: string;
  cameraMake?: string;
  cameraModel?: string;
  lensModel?: string;
  focalLength?: string;
  aperture?: string;
  shutterSpeed?: string;
  iso?: number;
};

function hasExif(photo: GalleryPhoto): boolean {
  return !!(photo.takenAt || photo.cameraModel || photo.lensModel || photo.aperture || photo.shutterSpeed || photo.iso);
}

// 在浏览器里预加载一张图片，让它进 HTTP 缓存——不是真的往页面里插入这张图，
// 单纯是为了下次真正显示的时候能直接命中缓存，不用重新等网络请求
function preloadImage(url: string) {
  const img = new window.Image();
  img.src = url;
}

// 快门速度、光圈这些术语本身已经是行业通用的简写格式（1/250s、f/1.8），
// 这里只负责把几个字段拼成一行，不做进一步的"人话翻译"
function formatExifLine(photo: GalleryPhoto): string[] {
  const lines: string[] = [];
  if (photo.takenAt) {
    lines.push(
      new Date(photo.takenAt).toLocaleString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
    );
  }
  const camera = [photo.cameraMake, photo.cameraModel].filter(Boolean).join(' ');
  if (camera) lines.push(camera);
  if (photo.lensModel) lines.push(photo.lensModel);
  const params = [photo.focalLength, photo.aperture, photo.shutterSpeed, photo.iso ? `ISO ${photo.iso}` : null].filter(Boolean);
  if (params.length > 0) lines.push(params.join('  ·  '));
  return lines;
}

export default function PhotoGallery({ photos }: { photos: GalleryPhoto[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [showExif, setShowExif] = useState(false);
  const touchStartX = useRef<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const showPrev = useCallback(
    () => setOpenIndex((i) => (i === null ? i : (i - 1 + photos.length) % photos.length)),
    [photos.length]
  );
  const showNext = useCallback(
    () => setOpenIndex((i) => (i === null ? i : (i + 1) % photos.length)),
    [photos.length]
  );

  // 打开大图时锁住背景滚动，键盘走 Esc / ← / → 三个键
  useEffect(() => {
    if (openIndex === null) return;

    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    function handleKeydown(e: KeyboardEvent) {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') showPrev();
      if (e.key === 'ArrowRight') showNext();
    }
    document.addEventListener('keydown', handleKeydown);

    return () => {
      document.body.style.overflow = prevOverflow;
      document.removeEventListener('keydown', handleKeydown);
    };
  }, [openIndex, close, showPrev, showNext]);

  // 每次切换到一张新图，把它左右相邻的两张预加载好，手感上感觉不到"切一张等一下"的卡顿。
  // 只预加载相邻各一张，不是全部——图集可能有几十上百张，全预加载等于变相把整个原图
  // 目录都下载一遍，浪费流量
  useEffect(() => {
    if (openIndex === null) return;
    preloadImage(photos[(openIndex + 1) % photos.length].url);
    preloadImage(photos[(openIndex - 1 + photos.length) % photos.length].url);
  }, [openIndex, photos]);

  // 每次换图片，"拍摄信息"面板默认收起，不用手动点关闭
  useEffect(() => {
    setShowExif(false);
  }, [openIndex]);

  function handleTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
  }
  function handleTouchEnd(e: React.TouchEvent) {
    if (touchStartX.current === null) return;
    const deltaX = e.changedTouches[0].clientX - touchStartX.current;
    touchStartX.current = null;
    // 50px 是个经验阈值：太小的话手指没拿稳的轻微晃动也会被误判成一次滑动
    if (Math.abs(deltaX) < 50) return;
    if (deltaX > 0) showPrev();
    else showNext();
  }

  const current = openIndex !== null ? photos[openIndex] : null;

  return (
    <>
      {/* 瀑布流布局：CSS columns 而不是 grid——grid 每个格子高度相等，不同宽高比的照片
          混在一起要么裁切要么留白参差不齐；columns 让每张图保持自己原本的宽高比，
          按列高度自动排布，是纯 CSS 方案，不需要 JS 量高度、不会有布局抖动 */}
      <div className="mt-8 columns-1 gap-4 sm:columns-2 md:columns-3">
        {photos.map((photo, index) => (
          <button
            key={photo.id}
            type="button"
            onClick={() => setOpenIndex(index)}
            className="relative mb-4 block w-full break-inside-avoid overflow-hidden bg-[var(--fg-5)] text-left"
            aria-label="点击查看原图"
          >
            <Image
              src={photo.url}
              alt={photo.alt}
              width={photo.width}
              height={photo.height}
              sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 33vw"
              className="w-full"
              priority={index === 0}
              loading={index === 0 ? undefined : 'lazy'}
              {...(photo.blurDataURL ? { placeholder: 'blur' as const, blurDataURL: photo.blurDataURL } : {})}
            />
          </button>
        ))}
      </div>

      {openIndex !== null && current && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90"
          onClick={close}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          <div className="absolute right-3 top-3 flex items-center gap-1">
            {hasExif(current) && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowExif((v) => !v);
                }}
                aria-label="拍摄信息"
                aria-pressed={showExif}
                className="flex h-11 w-11 items-center justify-center rounded-full text-lg text-white/80 hover:bg-white/10 hover:text-white"
              >
                ⓘ
              </button>
            )}
            <button
              type="button"
              onClick={close}
              aria-label="关闭"
              className="flex h-11 w-11 items-center justify-center rounded-full text-2xl text-white/80 hover:bg-white/10 hover:text-white"
            >
              ✕
            </button>
          </div>

          {photos.length > 1 && (
            <>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  showPrev();
                }}
                aria-label="上一张"
                className="absolute left-3 top-1/2 hidden h-14 w-14 -translate-y-1/2 items-center justify-center rounded-full text-3xl text-white/80 hover:bg-white/10 hover:text-white sm:flex"
              >
                ‹
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  showNext();
                }}
                aria-label="下一张"
                className="absolute right-3 top-1/2 hidden h-14 w-14 -translate-y-1/2 items-center justify-center rounded-full text-3xl text-white/80 hover:bg-white/10 hover:text-white sm:flex"
              >
                ›
              </button>
            </>
          )}

          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={current.url}
            alt={current.alt}
            onClick={(e) => e.stopPropagation()}
            style={
              current.blurDataURL
                ? { backgroundImage: `url(${current.blurDataURL})`, backgroundSize: 'cover', backgroundPosition: 'center' }
                : undefined
            }
            className="max-h-[92vh] max-w-[92vw] object-contain"
          />

          {showExif && hasExif(current) && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute bottom-14 left-1/2 max-w-[92vw] -translate-x-1/2 space-y-0.5 rounded-lg bg-black/60 px-4 py-3 text-center text-xs text-white/90"
            >
              {formatExifLine(current).map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
          )}

          {photos.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-black/40 px-3 py-1 text-xs text-white/80">
              {openIndex + 1} / {photos.length}
            </div>
          )}
        </div>
      )}
    </>
  );
}
