import { getSiteSettings } from '@/lib/settings';
import AdCodeRenderer from './AdCodeRenderer';

// 桌面端专用的广告栏，配合各个相册页面的 8:2 两栏布局使用。
// 移动端/平板（lg 断点以下）直接不渲染——窄屏本来就寸土寸金，硬塞一个
// 20% 宽的侧栏只会把主内容挤得更窄，不如直接不显示。
//
// 广告代码在 /monkey/settings 后台维护（SiteSetting.adCode1~adCode5），5 个广告位
// 各自独立一份，不是重复同一份代码——改完立即生效不用重新部署——真正执行
// <script> 的逻辑在 AdCodeRenderer 里（这个组件本身是 async Server Component，
// 不方便直接操作 DOM）。哪个广告位还没配置过代码（对应字段是空字符串），
// 就单独走占位区块兜底，不会让页面看起来是坏的。
function AdSlot({ width, height, label }: { width: number; height: number; label: string }) {
  return (
    <div
      style={{ aspectRatio: `${width} / ${height}` }}
      className="flex w-full shrink-0 items-center justify-center rounded border border-dashed border-[var(--fg-25)] bg-[var(--bg-color)] text-xs text-[var(--fg-40)]"
    >
      {label}
      <br />
      {width}×{height}
    </div>
  );
}

// 常见 IAB 广告尺寸，从上到下摆。数量不够用 count 兜底重复最后一个尺寸——
// 没必要为了"填满一栏"精确设计每个尺寸，反正外层面板本身有背景色，
// 占位块之后剩下的空间也是同一个颜色，视觉上不会露馅
const SLOT_SIZES: { width: number; height: number }[] = [
  { width: 300, height: 250 },
  { width: 300, height: 600 },
  { width: 300, height: 250 },
  { width: 300, height: 300 },
  { width: 300, height: 250 },
];

export default async function AdSidebar({ count = 5 }: { count?: number }) {
  const settings = await getSiteSettings();
  const codes = [settings.adCode1, settings.adCode2, settings.adCode3, settings.adCode4, settings.adCode5];
  const slots = Array.from({ length: count }, (_, i) => ({
    size: SLOT_SIZES[i % SLOT_SIZES.length],
    // count 超过 5（目前项目里没有这种用法，但留个兜底）就从头循环取代码，
    // 不会越界访问 undefined
    code: codes[i % codes.length],
  }));

  return (
    // items-stretch 是 CSS Grid 的默认值，不用显式写在这里——父级的两栏 grid 容器
    // 不会覆盖这个默认行为，所以这个 aside 本来就会被拉伸到跟旁边主内容区一样高。
    // 背景色 + 圆角边框把整个侧栏包成一个"面板"，占位块摆完之后剩下的空间
    // 就是这个面板本身的背景色，不是突兀的空白
    <aside className="hidden lg:flex lg:flex-col lg:gap-4 lg:rounded-lg lg:border lg:border-[var(--fg-10)] lg:bg-[var(--fg-5)] lg:p-4">
      {slots.map(({ size, code }, i) =>
        code?.trim() ? (
          <AdCodeRenderer key={i} code={code} />
        ) : (
          <AdSlot key={i} width={size.width} height={size.height} label={`广告位 ${i + 1}`} />
        )
      )}
    </aside>
  );
}
