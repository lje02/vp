'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  // 密码验证通过、但账号开了两步验证时，服务端不会直接发正式 session，
  // 这里切到"输验证码"这一步，跟登录表单本身分开渲染，避免让人以为还要重新填邮箱密码
  const [needsTwoFactor, setNeedsTwoFactor] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handlePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch('/api/monkey/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => null);
    setLoading(false);
    if (res.ok && data?.twoFactorRequired) {
      setNeedsTwoFactor(true);
      return;
    }
    if (res.ok) {
      router.push('/monkey');
      router.refresh();
    } else {
      setError(data?.error || '登录失败');
    }
  }

  async function handleCodeSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch('/api/monkey/login/verify-2fa', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code }),
    });
    setLoading(false);
    if (res.ok) {
      router.push('/monkey');
      router.refresh();
    } else {
      const data = await res.json().catch(() => null);
      setError(data?.error || '验证失败');
    }
  }

  if (needsTwoFactor) {
    return (
      <div className="mx-auto max-w-sm px-4 py-24">
        <h1 className="mb-1 text-xl">两步验证</h1>
        <p className="mb-6 text-sm text-[var(--fg-50)]">
          输入验证器 App 里显示的 6 位验证码，或者用一个备用码。
        </p>
        <form onSubmit={handleCodeSubmit} className="space-y-4">
          <input
            type="text"
            inputMode="numeric"
            placeholder="验证码 / 备用码"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            autoFocus
            className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2 tracking-widest"
            required
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
          >
            {loading ? '验证中…' : '验证'}
          </button>
          <button
            type="button"
            onClick={() => {
              setNeedsTwoFactor(false);
              setCode('');
              setError('');
            }}
            className="w-full text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]"
          >
            返回重新登录
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-sm px-4 py-24">
      <h1 className="mb-6 text-xl">管理员登录</h1>
      <form onSubmit={handlePasswordSubmit} className="space-y-4">
        <input
          type="email"
          placeholder="邮箱"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
        />
        <input
          type="password"
          placeholder="密码"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {loading ? '登录中…' : '登录'}
        </button>
      </form>
    </div>
  );
}
