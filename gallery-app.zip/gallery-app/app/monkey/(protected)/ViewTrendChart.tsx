import { prisma } from '@/lib/db';
import ViewTrendChartClient from './ViewTrendChartClient';

// 查询归查询，图表渲染（recharts 依赖 DOM/浏览器 API）归客户端组件——
// 这个文件本身是个 async Server Component，只负责把 AlbumViewDaily 按天聚合、
// 补全没有数据的日期为 0（不然横轴会因为缺数据点而不连续），再连同浏览量排行
// 一起传给 ViewTrendChartClient 去画。
export default async function ViewTrendChart() {
  const DAYS = 30;
  const since = new Date();
  since.setUTCDate(since.getUTCDate() - (DAYS - 1));
  since.setUTCHours(0, 0, 0, 0);

  const [daily, topAlbums] = await Promise.all([
    prisma.albumViewDaily.groupBy({
      by: ['date'],
      where: { date: { gte: since } },
      _sum: { count: true },
    }),
    prisma.album.findMany({
      orderBy: { viewCount: 'desc' },
      take: 5,
      select: { id: true, title: true, slug: true, viewCount: true },
    }),
  ]);

  const countByDateKey = new Map(daily.map((d) => [d.date.toISOString().slice(0, 10), d._sum.count ?? 0]));

  const points: { date: string; views: number }[] = [];
  for (let i = 0; i < DAYS; i++) {
    const d = new Date(since);
    d.setUTCDate(d.getUTCDate() + i);
    const key = d.toISOString().slice(0, 10);
    points.push({ date: key.slice(5), views: countByDateKey.get(key) ?? 0 }); // 只显示 MM-DD，年份对趋势图没意义
  }

  const hasAnyData = points.some((p) => p.views > 0) || topAlbums.some((a) => a.viewCount > 0);
  if (!hasAnyData) return null; // 完全没有浏览数据（新站/刚上线）时不显示这个板块，省得看着一片空白的图表

  return <ViewTrendChartClient points={points} topAlbums={topAlbums} />;
}
