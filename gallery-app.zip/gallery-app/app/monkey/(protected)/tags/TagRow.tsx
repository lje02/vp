'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { tagDotColor } from '@/lib/tag-color';

export default function TagRow({
  tag,
  count,
  allTags,
}: {
  tag: string;
  count: number;
  allTags: string[];
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [newName, setNewName] = useState(tag);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleRename() {
    const trimmed = newName.trim();
    if (!trimmed || trimmed === tag) {
      setEditing(false);
      setNewName(tag);
      return;
    }

    const willMerge = allTags.includes(trimmed);
    const confirmMsg = willMerge
      ? `"${trimmed}" 这个标签已经存在，这样改会把两个标签合并成一个，"${tag}" 下的 ${count} 个图集会并到 "${trimmed}" 里，确定吗？`
      : `确定把标签 "${tag}" 重命名为 "${trimmed}" 吗？会同步更新所有用到这个标签的图集（${count} 个）。`;
    if (!confirm(confirmMsg)) return;

    setLoading(true);
    setError('');
    const res = await fetch(`/api/monkey/tags/${encodeURIComponent(tag)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ newName: trimmed }),
    });
    setLoading(false);

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || '操作失败');
      return;
    }
    setEditing(false);
    router.refresh();
  }

  async function handleDelete() {
    if (!confirm(`确定删除标签 "${tag}" 吗？会从所有用到它的图集（${count} 个）里移除，图集本身不受影响。`)) return;
    setLoading(true);
    await fetch(`/api/monkey/tags/${encodeURIComponent(tag)}`, { method: 'DELETE' });
    setLoading(false);
    router.refresh();
  }

  if (editing) {
    return (
      <div className="flex items-center gap-2 py-2.5">
        <input
          autoFocus
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleRename();
            if (e.key === 'Escape') {
              setEditing(false);
              setNewName(tag);
              setError('');
            }
          }}
          className="flex-1 rounded border border-[var(--fg-20)] bg-transparent px-2 py-1 text-sm"
        />
        <button
          onClick={handleRename}
          disabled={loading}
          className="rounded px-3 py-1 text-sm text-[var(--accent-color)] hover:bg-[var(--fg-10)] disabled:opacity-50"
        >
          {loading ? '保存中…' : '保存'}
        </button>
        <button
          onClick={() => {
            setEditing(false);
            setNewName(tag);
            setError('');
          }}
          disabled={loading}
          className="rounded px-3 py-1 text-sm text-[var(--fg-50)] hover:bg-[var(--fg-10)]"
        >
          取消
        </button>
        {error && <span className="text-xs text-red-400">{error}</span>}
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between py-2.5 text-sm">
      <span>
        <span
          aria-hidden
          style={tagDotColor(tag)}
          className="mr-2 inline-block h-2 w-2 rounded-full align-middle"
        />
        {tag}
        <span className="ml-2 text-xs text-[var(--fg-40)]">{count} 个图集</span>
      </span>
      <div className="flex items-center gap-3 text-[var(--fg-50)]">
        <button onClick={() => setEditing(true)} className="hover:text-[var(--text-color)]">
          重命名/合并
        </button>
        <button onClick={handleDelete} disabled={loading} className="text-red-400 hover:text-red-300 disabled:opacity-50">
          删除
        </button>
      </div>
    </div>
  );
}
