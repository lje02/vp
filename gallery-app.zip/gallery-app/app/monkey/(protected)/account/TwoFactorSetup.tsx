'use client';

import { useState } from 'react';

type Step =
  | { kind: 'idle' }
  | { kind: 'enter-password'; action: 'setup' | 'disable' | 'regenerate' }
  | { kind: 'scan'; qrCodeDataUrl: string; base32Secret: string }
  | { kind: 'backup-codes'; codes: string[] };

async function postJson(url: string, body: unknown) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || '操作失败，重试一下');
  return data;
}

export default function TwoFactorSetup({ initialEnabled }: { initialEnabled: boolean }) {
  const [enabled, setEnabled] = useState(initialEnabled);
  const [step, setStep] = useState<Step>({ kind: 'idle' });
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function resetToIdle() {
    setStep({ kind: 'idle' });
    setPassword('');
    setCode('');
    setError('');
  }

  async function handlePasswordSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (step.kind !== 'enter-password') return;
    setSubmitting(true);
    setError('');
    try {
      if (step.action === 'setup') {
        const data = await postJson('/api/monkey/account/two-factor/setup', { password });
        setStep({ kind: 'scan', qrCodeDataUrl: data.qrCodeDataUrl, base32Secret: data.base32Secret });
        setPassword('');
      } else if (step.action === 'disable') {
        await postJson('/api/monkey/account/two-factor/disable', { password });
        setEnabled(false);
        resetToIdle();
      } else {
        const data = await postJson('/api/monkey/account/two-factor/backup-codes', { password });
        setStep({ kind: 'backup-codes', codes: data.backupCodes });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleConfirmCode(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      const data = await postJson('/api/monkey/account/two-factor/confirm', { code });
      setEnabled(true);
      setStep({ kind: 'backup-codes', codes: data.backupCodes });
      setCode('');
    } catch (err) {
      setError(err instanceof Error ? err.message : '验证失败');
    } finally {
      setSubmitting(false);
    }
  }

  if (step.kind === 'enter-password') {
    const titles = {
      setup: '开启两步验证前，先确认一下身份',
      disable: '关闭两步验证前，先确认一下身份',
      regenerate: '重新生成备用码前，先确认一下身份',
    } as const;
    return (
      <form onSubmit={handlePasswordSubmit} className="space-y-3 rounded border border-[var(--fg-15)] p-3">
        <p className="text-sm text-[var(--fg-70)]">{titles[step.action]}</p>
        <input
          type="password"
          autoFocus
          placeholder="当前密码"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={submitting || !password}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
          >
            {submitting ? '验证中…' : '确认'}
          </button>
          <button
            type="button"
            onClick={resetToIdle}
            className="rounded px-3 py-1.5 text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]"
          >
            取消
          </button>
        </div>
      </form>
    );
  }

  if (step.kind === 'scan') {
    return (
      <form onSubmit={handleConfirmCode} className="space-y-3 rounded border border-[var(--fg-15)] p-3">
        <p className="text-sm text-[var(--fg-70)]">
          用 Google Authenticator / 微信 / 1Password 等验证器 App 扫描下面的二维码：
        </p>
        {/* eslint-disable-next-line @next/next/no-img-element -- data URL，不是站内资源，走不了 next/image 的优化管线 */}
        <img
          src={step.qrCodeDataUrl}
          alt="两步验证二维码"
          className="mx-auto h-48 w-48 rounded bg-white p-2"
        />
        <details className="text-xs text-[var(--fg-50)]">
          <summary className="cursor-pointer">扫不了？手动输入密钥</summary>
          <p className="mt-1 break-all font-mono">{step.base32Secret}</p>
        </details>
        <p className="text-sm text-[var(--fg-70)]">扫码后，输入 App 里显示的 6 位验证码完成绑定：</p>
        <input
          type="text"
          inputMode="numeric"
          autoFocus
          maxLength={6}
          placeholder="6 位验证码"
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
          className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm tracking-widest outline-none"
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={submitting || code.length !== 6}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
          >
            {submitting ? '验证中…' : '确认开启'}
          </button>
          <button
            type="button"
            onClick={resetToIdle}
            className="rounded px-3 py-1.5 text-sm text-[var(--fg-50)] hover:text-[var(--text-color)]"
          >
            取消
          </button>
        </div>
      </form>
    );
  }

  if (step.kind === 'backup-codes') {
    return (
      <div className="space-y-3 rounded border border-[var(--fg-15)] p-3">
        <p className="text-sm" style={{ color: 'var(--accent-color)' }}>
          {enabled ? '两步验证已开启' : ''} 备用码只显示这一次，请立刻保存到安全的地方
        </p>
        <p className="text-xs text-[var(--fg-50)]">
          手机丢了或者卸载了验证器 App 时，可以用下面任意一个备用码代替 6 位验证码登录，每个码只能用一次。
        </p>
        <div className="grid grid-cols-2 gap-2 rounded bg-[var(--fg-5)] p-3 font-mono text-sm">
          {step.codes.map((c) => (
            <span key={c}>{c}</span>
          ))}
        </div>
        <button
          type="button"
          onClick={resetToIdle}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)]"
        >
          我已保存
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <p className="text-sm text-[var(--fg-70)]">
        状态：
        <span style={enabled ? { color: 'var(--accent-color)' } : undefined} className={enabled ? '' : 'text-[var(--fg-50)]'}>
          {enabled ? '已开启' : '未开启'}
        </span>
      </p>
      <p className="text-xs text-[var(--fg-40)]">
        开启后，登录时除了密码，还需要验证器 App 里的 6 位一次性验证码。只对超级管理员账号生效。
      </p>
      <div className="flex flex-wrap gap-2">
        {!enabled && (
          <button
            type="button"
            onClick={() => setStep({ kind: 'enter-password', action: 'setup' })}
            style={{ backgroundColor: 'var(--accent-color)' }}
            className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)]"
          >
            开启两步验证
          </button>
        )}
        {enabled && (
          <>
            <button
              type="button"
              onClick={() => setStep({ kind: 'enter-password', action: 'regenerate' })}
              className="rounded border border-[var(--fg-20)] px-3 py-1.5 text-sm text-[var(--fg-70)] hover:text-[var(--text-color)]"
            >
              重新生成备用码
            </button>
            <button
              type="button"
              onClick={() => setStep({ kind: 'enter-password', action: 'disable' })}
              className="rounded border border-red-400/40 px-3 py-1.5 text-sm text-red-400 hover:bg-red-400/10"
            >
              关闭两步验证
            </button>
          </>
        )}
      </div>
    </div>
  );
}
