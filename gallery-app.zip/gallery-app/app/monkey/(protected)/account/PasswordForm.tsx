'use client';

import { useState } from 'react';

export default function PasswordForm() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const mismatch = confirmPassword.length > 0 && newPassword !== confirmPassword;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSuccess(false);

    if (newPassword !== confirmPassword) {
      setError('两次输入的新密码不一致');
      return;
    }

    setSaving(true);
    const res = await fetch('/api/monkey/account/password', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    setSaving(false);

    if (res.ok) {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setSuccess(true);
    } else {
      const data = await res.json().catch(() => null);
      setError(data?.error || '修改失败，重试一下');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="mb-1 block text-xs text-[var(--fg-50)]">当前密码</label>
        <input
          type="password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
      </div>
      <div>
        <label className="mb-1 block text-xs text-[var(--fg-50)]">新密码（至少 10 位，含字母和数字）</label>
        <input
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
      </div>
      <div>
        <label className="mb-1 block text-xs text-[var(--fg-50)]">确认新密码</label>
        <input
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-15)] bg-transparent px-2.5 py-1.5 text-sm outline-none"
        />
        {mismatch && <p className="mt-1 text-xs text-red-400">两次输入不一致</p>}
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}
      {success && <p className="text-sm" style={{ color: 'var(--accent-color)' }}>密码已修改</p>}

      <button
        type="submit"
        disabled={saving || !currentPassword || !newPassword || mismatch}
        style={{ backgroundColor: 'var(--accent-color)' }}
        className="rounded px-3 py-1.5 text-sm text-[var(--accent-contrast)] disabled:cursor-default disabled:bg-[var(--fg-10)] disabled:text-[var(--fg-40)]"
      >
        {saving ? '保存中…' : '修改密码'}
      </button>
    </form>
  );
}
