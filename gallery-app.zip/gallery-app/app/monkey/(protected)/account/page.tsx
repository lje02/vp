import { requireAdminPage, getCurrentAdmin } from '@/lib/auth';
import PasswordForm from './PasswordForm';

export const dynamic = 'force-dynamic';

export default async function AccountPage() {
  await requireAdminPage();
  const admin = await getCurrentAdmin();

  return (
    <div className="mx-auto max-w-md px-4 py-8">
      <h1 className="mb-1 text-xl">账号设置</h1>
      <p className="mb-6 text-sm text-[var(--fg-50)]">
        {admin?.email}
        {admin?.role === 'SUPER_ADMIN' ? '（超级管理员）' : ''}
      </p>
      <PasswordForm />
    </div>
  );
}
