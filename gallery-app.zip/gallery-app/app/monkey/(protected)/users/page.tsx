import { prisma } from '@/lib/db';
import UserRow from './UserRow';
import { requirePermissionPage } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export default async function UsersPage() {
  await requirePermissionPage('users');
  const [users, privateAlbums] = await Promise.all([
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        email: true,
        createdAt: true,
        albums: { select: { id: true } },
      },
    }),
    // 只有私密相册才需要授权，公开相册人人都能看，不用出现在这个勾选列表里
    prisma.album.findMany({
      where: { visibility: 'PRIVATE' },
      orderBy: { title: 'asc' },
      select: { id: true, title: true, slug: true },
    }),
  ]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-1 text-xl">用户管理</h1>
      <p className="mb-6 text-sm text-[var(--fg-50)]">
        前台注册的普通用户在这里管理，默认什么私密相册都看不了，需要逐个授权。
      </p>

      {users.length === 0 ? (
        <p className="py-8 text-center text-[var(--fg-50)]">还没有用户注册</p>
      ) : (
        <div className="divide-y divide-[var(--fg-10)] border-t border-[var(--fg-10)]">
          {users.map((user) => (
            <UserRow
              key={user.id}
              user={{
                id: user.id,
                email: user.email,
                createdAt: user.createdAt.toISOString(),
                authorizedAlbumIds: user.albums.map((a) => a.id),
              }}
              privateAlbums={privateAlbums}
            />
          ))}
        </div>
      )}
    </div>
  );
}
