import { prisma } from '@/lib/db';
import { requireSuperAdminPage } from '@/lib/auth';
import AdminsPanel from './AdminsPanel';

export const dynamic = 'force-dynamic';

export default async function AdminsPage() {
  await requireSuperAdminPage();

  const admins = await prisma.adminUser.findMany({
    orderBy: { createdAt: 'asc' },
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
      createdAt: true,
      lockedUntil: true,
    },
  });

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-1 text-xl">管理员管理</h1>
      <p className="mb-6 text-sm text-[var(--fg-50)]">
        只有超级管理员能看到这个页面。子管理员按下面三个模块分别授权，勾了才能碰对应的功能。
        超级管理员账号（包括你自己）不能在这里改，需要的话去服务器上跑{' '}
        <code className="rounded bg-[var(--fg-10)] px-1 py-0.5">npx tsx prisma/create-admin.ts</code>。
      </p>

      <AdminsPanel
        admins={admins.map((a) => ({
          ...a,
          createdAt: a.createdAt.toISOString(),
          lockedUntil: a.lockedUntil ? a.lockedUntil.toISOString() : null,
        }))}
      />
    </div>
  );
}
