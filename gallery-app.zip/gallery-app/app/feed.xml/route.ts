import { prisma } from '@/lib/db';
import { getSiteSettings } from '@/lib/settings';
import { siteUrl } from '@/lib/site-url';
import { publicUrl } from '@/lib/storage';

export const revalidate = 3600;

// 只放最新已发布的公开相册——私密相册的标题/描述本身不算敏感信息（跟 AlbumCard 首页卡片
// 同一个尺度：见之前讨论过的"封面预告图"设计，私密相册的存在和标题本来就不是完全保密的），
// 但 RSS 阅读器/生成的静态文件通常会被各种聚合器抓取转存，私密相册没必要跟着公开相册一起
// 出现在一个所有人都能订阅到的公开列表里，稳妥起见还是只放 PUBLIC 的。
const FEED_ITEM_LIMIT = 20;

// 跟 lib/navlinks.ts / app/sitemap.ts 保持一致的转义方式，避免标题/描述里的
// & < > 之类的字符破坏 XML 结构
function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export async function GET() {
  const base = siteUrl();
  const settings = await getSiteSettings();

  // docker build 阶段拿不到真实 DATABASE_URL，跟 app/sitemap.ts 保持一致的兜底策略：
  // 查询失败就返回一个空的 feed，不让构建期预渲染把整个 build 搞挂
  let albums: Awaited<ReturnType<typeof fetchAlbums>> = [];
  try {
    albums = await fetchAlbums();
  } catch {
    // 数据库还没跑迁移，或者构建期查询失败时兜底为空
  }

  const items = albums
    .map((album) => {
      const link = `${base}/${album.slug}`;
      const coverImage = album.coverKey
        ? `<enclosure url="${escapeXml(publicUrl(album.coverKey))}" type="image/webp" />`
        : '';
      return `
    <item>
      <title>${escapeXml(album.title)}</title>
      <link>${link}</link>
      <guid isPermaLink="true">${link}</guid>
      <pubDate>${(album.publishedAt ?? album.createdAt).toUTCString()}</pubDate>
      ${album.description ? `<description>${escapeXml(album.description)}</description>` : ''}
      ${coverImage}
    </item>`;
    })
    .join('');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escapeXml(settings.siteTitle)}</title>
    <link>${base}</link>
    <description>${escapeXml(settings.siteDescription)}</description>
    <language>zh-CN</language>
    <atom:link href="${base}/feed.xml" rel="self" type="application/rss+xml" />${items}
  </channel>
</rss>`;

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/rss+xml; charset=utf-8',
      // Route Handler 自己的 revalidate 只控制 Next.js 内部的 ISR 重新生成节奏，
      // 补一个标准的 Cache-Control，让中间的 CDN/浏览器也知道可以缓存多久，
      // 减少每次订阅客户端拉取都直接打到源站
      'Cache-Control': 'public, max-age=0, s-maxage=3600, stale-while-revalidate=86400',
    },
  });
}

function fetchAlbums() {
  return prisma.album.findMany({
    where: { status: 'PUBLISHED', visibility: 'PUBLIC' },
    select: { slug: true, title: true, description: true, coverKey: true, publishedAt: true, createdAt: true },
    orderBy: { publishedAt: 'desc' },
    take: FEED_ITEM_LIMIT,
  });
}
