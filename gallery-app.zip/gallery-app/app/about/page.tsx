import { getSiteSettings } from '@/lib/settings';
import type { Metadata } from 'next';

export const revalidate = 3600;

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  const firstParagraph = settings.aboutContent.split('\n').map((p) => p.trim()).find(Boolean);

  return {
    title: '关于',
    description: firstParagraph || settings.siteDescription,
  };
}

export default async function AboutPage() {
  const settings = await getSiteSettings();
  const paragraphs = settings.aboutContent
    .split('\n')
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="mb-6 text-xl">关于</h1>
      {paragraphs.length > 0 ? (
        <div className="space-y-4 text-sm leading-relaxed text-[var(--fg-80)]">
          {paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      ) : (
        <p className="text-sm text-[var(--fg-50)]">站长还没有填写关于页内容。</p>
      )}
    </div>
  );
}
