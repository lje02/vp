'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

// 只允许跳回站内路径，且必须是单个 /（不能是 //evil.com 这种"看起来像相对路径、
// 实际会被浏览器当成协议相对 URL 跳到外站"的写法）——不然 ?next= 就是一个开放重定向漏洞，
// 可以被用来伪造"从本站发出的链接"钓鱼
function sanitizeNext(next: string | null): string {
  if (!next || !next.startsWith('/') || next.startsWith('//')) return '/';
  return next;
}

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = sanitizeNext(searchParams.get('next'));

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    setLoading(false);
    if (res.ok) {
      router.push(next);
      router.refresh();
    } else {
      const data = await res.json().catch(() => ({}));
      setError(data.error || '登录失败');
    }
  }

  return (
    <div className="mx-auto max-w-sm px-4 py-24">
      <h1 className="mb-6 text-xl">登录</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          placeholder="邮箱"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
          autoComplete="email"
        />
        <input
          type="password"
          placeholder="密码"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded border border-[var(--fg-20)] bg-transparent px-3 py-2"
          required
          autoComplete="current-password"
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          style={{ backgroundColor: 'var(--accent-color)' }}
          className="w-full rounded py-2 text-[var(--accent-contrast)] disabled:opacity-50"
        >
          {loading ? '登录中…' : '登录'}
        </button>
      </form>

      <p className="mt-4 text-sm text-[var(--fg-60)]">
        还没有账号？
        <Link href="/register" className="ml-1 underline hover:text-[var(--accent-color)]">
          去注册
        </Link>
      </p>
    </div>
  );
}
