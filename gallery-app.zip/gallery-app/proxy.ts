import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { jwtVerify } from 'jose';
import { getAuthSecretBytes } from '@/lib/auth-secret';
import { getClientIp } from '@/lib/client-ip';
import { isRateLimited } from '@/lib/rate-limit';

const secret = getAuthSecretBytes();

// 常见扫描器/爬虫探测的路径特征。命中的直接 404，不进 /[slug] 的数据库查询。
// 因为本站是 flat virtual routing（域名/xxx 先当图集 slug 查、查不到再当标签名查），
// 不拦的话每一条扫描请求都会白白打两次 Postgres。
const SCAN_PATTERN =
  /(^\/\.(?:env|git|DS_Store)(\/|$))|(^\/(?:wp-admin|wp-login\.php|wp-content|wp-includes|xmlrpc\.php|phpmyadmin|pma)(\/|$))|(\.(?:sql|bak|old|swp|conf|ini|log)$)|(^\/(?:config|admin|administrator|\.aws|\.ssh)(\/|$))/i;

// 通用限流：同一 IP 在窗口期内请求数超过阈值就先拦一道，
// 主要防的是"路径不在上面特征库里，但短时间内高频枚举很多不同路径"这种模式
// （比如暴力猜图集 slug），特征匹配挡不住这种。
const GENERAL_WINDOW_MS = 10_000;
const GENERAL_MAX = 60; // 10 秒内同一 IP 最多 60 个请求，正常用户浏览远够用

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (SCAN_PATTERN.test(pathname)) {
    return new NextResponse(null, { status: 404 });
  }

  const ip = getClientIp(req);
  if (ip !== 'unknown' && (await isRateLimited('scanguard', ip, { windowMs: GENERAL_WINDOW_MS, max: GENERAL_MAX }))) {
    return new NextResponse('Too Many Requests', { status: 429 });
  }

  // 登录页和登录接口本身不拦截
  if (pathname === '/monkey/login' || pathname === '/api/monkey/login') {
    return NextResponse.next();
  }

  if (pathname.startsWith('/monkey') || pathname.startsWith('/api/monkey')) {
    const token = req.cookies.get('admin_session')?.value;
    if (!token) {
      return redirectToLogin(req);
    }
    try {
      await jwtVerify(token, secret);
      return NextResponse.next();
    } catch {
      return redirectToLogin(req);
    }
  }

  return NextResponse.next();
}

function redirectToLogin(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const loginUrl = new URL('/monkey/login', req.url);
  return NextResponse.redirect(loginUrl);
}

// 覆盖全站（排除 Next 静态资源、图片优化接口和常见静态文件后缀），
// 这样扫描拦截和限流才能罩住 /[slug] 这种能匹配任意路径的动态路由，
// 不只是 /monkey 后台。
export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon\\.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js|map)$).*)'],
};
