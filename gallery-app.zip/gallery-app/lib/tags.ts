import { prisma } from '@/lib/db';
import { redis } from '@/lib/redis';

export type TagCount = { tag: string; count: number };

// 标签现在是真正的 Tag 表 + 隐式多对多关系（见 prisma/schema.prisma），
// 不再需要 unnest() 原生 SQL：直接用 Prisma 的关系计数（_count）统计每个标签下有多少图集。
//
// onlyPublished=true（前台用）只统计已发布图集下的标签，没有已发布图集的标签也不会出现；
// false（后台管理用）统计全部图集（含草稿），不然草稿上打的标签在后台管理页面里看不到、也没法重命名/删除。
//
// 前台这条（onlyPublished=true）会被首页和 /tags 页面每次请求都调一次，是全表 _count 聚合，
// 图集/标签一多会比 lib/settings.ts 那批缓存过的查询贵不少。这里给它加个短 TTL 缓存，
// 但故意不做主动失效（不像 settings/categories/navlinks 那样在写操作里 del 缓存）：
// 标签计数只是个展示用的统计数字，发布/删除图集或改标签名之后晚个几十秒才反映到计数上
// 完全不影响使用，换来的是不用在建/改/删/批量操作图集、改标签名等一堆写入路径里
// 都记得补一次 invalidate（漏改一处就会有缓存不一致的 bug）。
// 后台管理页（onlyPublished=false）不缓存：这里追求所见即所得，管理员改完标签或图集状态
// 马上要能在后台看到准确数字，用量也小得多，没必要为了省这一点查库开销引入延迟。
const CACHE_KEY = 'gallery:tagcounts:published';
const CACHE_TTL_SEC = 60;

async function loadTagCounts(onlyPublished: boolean): Promise<TagCount[]> {
  const tags = await prisma.tag.findMany({
    select: {
      name: true,
      _count: {
        select: {
          albums: onlyPublished ? { where: { status: 'PUBLISHED' } } : true,
        },
      },
    },
  });

  const counts = tags
    .map((t) => ({ tag: t.name, count: t._count.albums }))
    .filter((t) => !onlyPublished || t.count > 0);

  if (onlyPublished) {
    counts.sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
  } else {
    counts.sort((a, b) => a.tag.localeCompare(b.tag));
  }

  return counts;
}

export async function getTagCounts(onlyPublished: boolean): Promise<TagCount[]> {
  if (!onlyPublished) {
    // 后台管理用，不缓存，理由见上面的注释
    return loadTagCounts(false);
  }

  if (redis) {
    try {
      const cached = await redis.get(CACHE_KEY);
      if (cached) return JSON.parse(cached) as TagCount[];
    } catch (err) {
      console.error('[tags] redis read failed, falling back to db:', err);
    }
  }

  const counts = await loadTagCounts(true);

  if (redis) {
    redis.set(CACHE_KEY, JSON.stringify(counts), 'EX', CACHE_TTL_SEC).catch((err) => {
      console.error('[tags] redis write failed:', err);
    });
  }

  return counts;
}
