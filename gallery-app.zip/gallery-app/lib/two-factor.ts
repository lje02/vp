import { TOTP, Secret } from 'otpauth';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'node:crypto';
import { encryptTotpSecret, decryptTotpSecret } from '@/lib/totp-crypto';

// digits/period/algorithm 用库默认值（6 位、30 秒、SHA1）——这是 Google Authenticator /
// 微信 / 1Password 等主流验证器 App 唯一都支持的组合，改成 SHA256 之类"更强"的算法
// 反而会导致一部分 App 扫出来的码验证不过。
const ISSUER = 'Gallery Admin';
const BACKUP_CODE_COUNT = 8;
const BACKUP_CODE_LENGTH = 10; // 纯数字，跟 6 位验证码一眼能区分开，抄的时候也不容易输错

function buildTotp(label: string, secret: Secret) {
  return new TOTP({ issuer: ISSUER, label, secret });
}

/**
 * 开始绑定流程：生成一个新的随机密钥，加密后返回密文（用来先存进
 * AdminUser.twoFactorSecret，此时 twoFactorEnabled 还是 false），以及给前端
 * 展示二维码用的 otpauth:// URI。
 *
 * 注意这一步还没有真正"开启"两步验证，必须等 confirmTotpEnrollment 用一个
 * 当下有效的验证码验证通过之后才算数——避免用户以为扫了码就万事大吉，
 * 结果验证器 App 里其实没扫成功，下次登录直接被锁在门外。
 */
export function beginTotpEnrollment(email: string) {
  const secret = new Secret({ size: 20 });
  const totp = buildTotp(email, secret);
  return {
    encryptedSecret: encryptTotpSecret(secret.base32),
    otpauthUrl: totp.toString(),
    base32Secret: secret.base32, // 给扫不了码的人手动输入用
  };
}

/**
 * 校验一个 6 位验证码是否跟给定的（已解密）密钥匹配。
 * window: 1 表示允许当前时间窗口前后各一个 30 秒窗口的偏差，容忍手机时间稍微不准，
 * 不宜再放宽——每多放宽一个窗口，攻击者能撞中的时间窗口就多一倍。
 */
export function verifyTotpToken(encryptedSecret: string, token: string, email: string): boolean {
  const cleaned = token.replace(/\s+/g, '');
  if (!/^\d{6}$/.test(cleaned)) return false;
  const secret = Secret.fromBase32(decryptTotpSecret(encryptedSecret));
  const totp = buildTotp(email, secret);
  return totp.validate({ token: cleaned, window: 1 }) !== null;
}

/**
 * 生成一批新的备用码：明文只在这一次返回给前端展示（离开这个函数之后就再也拿不到了，
 * 提示用户当场保存），数据库里存的是每个码的 bcrypt 哈希，跟登录密码同等对待。
 */
export async function generateBackupCodes(): Promise<{ plain: string[]; hashed: string }> {
  const plain = Array.from({ length: BACKUP_CODE_COUNT }, () => {
    // 10 位纯数字，用 randomBytes 而不是 Math.random，抽样均匀且不可预测
    let code = '';
    const bytes = randomBytes(BACKUP_CODE_LENGTH);
    for (let i = 0; i < BACKUP_CODE_LENGTH; i++) code += (bytes[i] % 10).toString();
    return code;
  });
  const hashes = await Promise.all(plain.map((code) => bcrypt.hash(code, 10)));
  return { plain, hashed: JSON.stringify(hashes) };
}

/**
 * 用备用码登录：命中就把这个码从数组里移除（一次性，用过即作废）并返回新的
 * hashed 数组存回数据库；没命中返回 null，调用方按"验证码错误"处理。
 */
export async function consumeBackupCode(
  hashedCodesJson: string | null,
  candidate: string,
): Promise<{ remaining: string } | null> {
  if (!hashedCodesJson) return null;
  let hashes: string[];
  try {
    hashes = JSON.parse(hashedCodesJson);
  } catch {
    return null;
  }
  const cleaned = candidate.replace(/\s+/g, '');
  for (let i = 0; i < hashes.length; i++) {
    // eslint-disable-next-line no-await-in-loop -- 备用码只有 8 个，逐个比对开销可忽略，
    // 换成 Promise.all 并发反而会让所有哈希同时算，没必要
    if (await bcrypt.compare(cleaned, hashes[i])) {
      const remaining = [...hashes.slice(0, i), ...hashes.slice(i + 1)];
      return { remaining: JSON.stringify(remaining) };
    }
  }
  return null;
}
