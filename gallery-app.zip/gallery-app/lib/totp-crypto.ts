import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { getAuthSecretBytes } from '@/lib/auth-secret';

// TOTP 密钥（还有备用码，虽然备用码是另外用 bcrypt 哈希的）落库前要加密，不能明文存 —— 跟密码不一样，
// 密码只需要"能校验"，用单向哈希就够；TOTP 密钥每次登录都要用它重新算一遍验证码去比对，
// 所以必须是可逆的对称加密，不能哈希。
//
// 加密密钥直接从 AUTH_SECRET 派生（SHA-256 摘要，正好 32 字节 = AES-256 要求的 key 长度），
// 不单独占用一个新的环境变量——没必要为了一个功能就多一个需要妥善保管的密钥，
// AUTH_SECRET 本来就是"泄露了后台就全完"的敏感等级，复用它不会降低安全性。
const ALGO = 'aes-256-gcm';

function deriveKey(): Buffer {
  return createHash('sha256').update(getAuthSecretBytes()).digest();
}

/**
 * 加密 TOTP 密钥，返回 "iv:authTag:密文" 三段拼接的 base64 字符串，存进
 * AdminUser.twoFactorSecret。IV 每次加密随机生成，不能复用。
 */
export function encryptTotpSecret(plainSecret: string): string {
  const key = deriveKey();
  const iv = randomBytes(12); // GCM 推荐 12 字节 IV
  const cipher = createCipheriv(ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(plainSecret, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv.toString('base64'), authTag.toString('base64'), encrypted.toString('base64')].join(':');
}

/**
 * 解密出原始 TOTP 密钥。密文格式不对、认证标签校验不通过（数据被篡改，或者
 * AUTH_SECRET 换了）都会抛错——调用方不需要特殊处理，让它自然报 500 即可，
 * 这种情况本身就意味着环境配置出了问题，不是用户能通过重试解决的。
 */
export function decryptTotpSecret(payload: string): string {
  const [ivB64, authTagB64, dataB64] = payload.split(':');
  if (!ivB64 || !authTagB64 || !dataB64) {
    throw new Error('无效的两步验证密钥密文格式');
  }
  const key = deriveKey();
  const decipher = createDecipheriv(ALGO, key, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(authTagB64, 'base64'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(dataB64, 'base64')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}
