import { prisma } from '@/lib/db';
import { redis } from '@/lib/redis';

export type SiteSettings = {
  siteTitle: string;
  siteDescription: string;
  logoKey: string | null;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  icpNumber: string;
  contactInfo: string;
  aboutContent: string;
  adCode1: string;
  adCode2: string;
  adCode3: string;
  adCode4: string;
  adCode5: string;
  mobileAdCode1: string;
  mobileAdCode2: string;
  mobileAdCode3: string;
};

const DEFAULTS: SiteSettings = {
  siteTitle: 'Gallery',
  siteDescription: '一个简单的图集展示站',
  logoKey: null,
  backgroundColor: '#1e1e1e',
  textColor: '#f2f2f0',
  accentColor: '#ffffff',
  icpNumber: '',
  contactInfo: '',
  aboutContent: '',
  adCode1: '',
  adCode2: '',
  adCode3: '',
  adCode4: '',
  adCode5: '',
  mobileAdCode1: '',
  mobileAdCode2: '',
  mobileAdCode3: '',
};

// 根 layout 里每个页面都会调一次 getSiteSettings，这是全站请求量最大的一个查询。
// 用 Redis 缓存一份，TTL 给得比较短（够用就行，不追求"改了设置立刻全局生效"，
// 后台保存时会主动 del 这个 key，配合 revalidatePath 做到基本即时生效）。
// 没配 REDIS_URL，或者 Redis 抖了，都直接退回原来的查库逻辑，不影响正常访问。
const CACHE_KEY = 'gallery:settings';
const CACHE_TTL_SEC = 300;

// 缓存未命中时（TTL 过期或冷启动）可能同一瞬间涌进来一批并发请求，
// 如果每个请求各自查一次库、各自写一次缓存，等于缓存没起到该有的保护作用，
// 流量稍微一抖 Postgres 就跟着抖。这里用一个模块级的 in-flight promise 做单飞：
// 第一个未命中的请求发起真正的查询并把 promise 存起来，之后同时到达的请求直接
// 复用这同一个 promise 等结果，而不是各自再查一次库。查询结束后（不管成功失败）
// 清掉这个变量，下一次未命中再重新发起。
let inFlightQuery: Promise<SiteSettings> | null = null;

async function fetchSettingsFromDb(): Promise<SiteSettings> {
  try {
    const row = await prisma.siteSetting.findUnique({ where: { id: 1 } });
    return row ? { ...DEFAULTS, ...row } : DEFAULTS;
  } catch {
    // 表还没迁移到、或者查询失败时兜底，不影响页面渲染
    return DEFAULTS;
  }
}

export async function getSiteSettings(): Promise<SiteSettings> {
  if (redis) {
    try {
      const cached = await redis.get(CACHE_KEY);
      // 跟 DEFAULTS 合并一下再返回：如果这份缓存是上一版代码写进去的（比如刚上线加了新字段，
      // 缓存还没过期），JSON 里就不会有新字段，直接强转成 SiteSettings 会带出 undefined，
      // 下游代码一旦对这些字段调用 .trim() 之类的方法就直接 500。合并 DEFAULTS 兜底缺失字段，
      // 等这条缓存自然过期（或后台保存设置时主动 invalidate）后就会是完整的新结构。
      if (cached) return { ...DEFAULTS, ...(JSON.parse(cached) as Partial<SiteSettings>) };
    } catch (err) {
      console.error('[settings] redis read failed, falling back to db:', err);
    }
  }

  if (!inFlightQuery) {
    inFlightQuery = fetchSettingsFromDb().finally(() => {
      inFlightQuery = null;
    });
  }
  const settings = await inFlightQuery;

  if (redis) {
    redis.set(CACHE_KEY, JSON.stringify(settings), 'EX', CACHE_TTL_SEC).catch((err) => {
      // 写缓存失败不影响这次请求，本来就查到数据了；下次请求会再查一次库，问题不大
      console.error('[settings] redis write failed:', err);
    });
  }

  return settings;
}

// 后台保存设置之后调用，让下一次请求立刻拿到新数据，不用等 TTL 过期。
export async function invalidateSiteSettingsCache(): Promise<void> {
  if (!redis) return;
  try {
    await redis.del(CACHE_KEY);
  } catch (err) {
    console.error('[settings] redis cache invalidation failed:', err);
  }
}
