import { PHASE_PRODUCTION_BUILD } from 'next/constants';

// 单独拆出来是因为 proxy.ts 跑在 Edge runtime 里，不能引入 next/headers 之类的 Node API，
// 但两边都要在启动时校验密钥是否配置好，且要算出同一把密钥。
//
// 没配密钥时，process.env.XXX! 会把字符串 "undefined" 当密钥用——签发和校验用的是同一个
// 错误的默认值，两边刚好能对上，看起来"正常工作"，但实际上任何人只要知道这个默认值
// 就能伪造登录 cookie，所以必须尽早报错。
//
// 但「尽早」不能早到 `next build` 里去：build 阶段的 "Collecting page data" 步骤会
// import 到所有路由（包括登录接口），而 build 容器里通常没有运行时的 .env
// （.env 是 docker-compose 用 env_file 在启动容器时才挂进去的），如果这里照样抛错，
// 会直接把镜像构建打断。用 Next.js 内置的 NEXT_PHASE 判断出"现在是不是在 build"，
// build 阶段先放行，等真正 `next start` 跑起来（或者本地 `next dev`）时该报错还是照样报错。
const isBuildPhase = process.env.NEXT_PHASE === PHASE_PRODUCTION_BUILD;

const cachedSecrets = new Map<string, Uint8Array>();

function getSecretBytes(envName: string): Uint8Array {
  const cached = cachedSecrets.get(envName);
  if (cached) return cached;

  const value = process.env[envName];
  if (!value || value.length < 16) {
    if (isBuildPhase) {
      // build 阶段用不到真实密钥（没有请求进来），塞个占位值让 import 能过就行
      return new TextEncoder().encode(`build-phase-placeholder-${envName}`);
    }
    throw new Error(
      `${envName} 未设置或长度不足 16 位。请在 .env 中配置一个足够长的随机字符串（例如 openssl rand -base64 32）。`,
    );
  }
  const bytes = new TextEncoder().encode(value);
  cachedSecrets.set(envName, bytes);
  return bytes;
}

export function getAuthSecretBytes(): Uint8Array {
  return getSecretBytes('AUTH_SECRET');
}

// 前台用户 session 用单独一把密钥，跟管理员的 AUTH_SECRET 完全隔离——
// 就算哪层代码疏忽（比如 cookie 名判断写错），用错密钥签发的 token 在另一边
// 也是直接验签失败，不是靠"角色声明字段"这一层软校验单独兜底。
export function getUserAuthSecretBytes(): Uint8Array {
  return getSecretBytes('USER_AUTH_SECRET');
}
