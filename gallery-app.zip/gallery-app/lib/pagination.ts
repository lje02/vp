export const PAGE_SIZE = 16;

export function getPageParams(searchParams: { [key: string]: string | string[] | undefined }) {
  const raw = searchParams.page;
  const page = Math.max(1, parseInt(Array.isArray(raw) ? raw[0] : raw || '1', 10) || 1);
  return {
    page,
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  };
}

export function getTotalPages(totalCount: number) {
  return Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
}
