// 封面卡片上"谁发布的"角标文案。规则很简单，就是没必要为这么小一件事
// 单独包一层复杂的展示名逻辑：AdminUser 表本来就没有"昵称/展示名"字段
// （只有 email），所以子管理员就用邮箱 @ 前面那截，超级管理员统一显示
// "Admin"，不区分具体是哪个超级管理员账号——多个超级管理员的场景下，
// 这个角标本来的意图更接近"这是官方/最高权限账号发布的"这么一个信任标记，
// 而不是署名，没必要精确到具体是谁。
export function publisherBadgeLabel(publisher: { role: 'SUPER_ADMIN' | 'ADMIN'; email: string } | null | undefined): string | null {
  if (!publisher) return null;
  if (publisher.role === 'SUPER_ADMIN') return 'Admin';
  const prefix = publisher.email.split('@')[0];
  return prefix || null;
}
