import { prisma } from '@/lib/db';

/**
 * 给 icon.tsx / apple-icon.tsx 用：直接从数据库读 logo 的 base64 数据。
 * 特意跟 lib/settings.ts 分开、单独查表，避免每个页面都要查的 getSiteSettings()
 * 也跟着带上这份图片数据。
 *
 * 这里不再对外发起 fetch 请求去 R2 拉图——之前那种做法会经过 Cloudflare，
 * 容易被 Bot Fight Mode 之类的机器人防护拦成 403，导致 favicon 生成失败退回文字版。
 * 数据存在数据库里，直接查表拿到，不用再走一次网络。
 */
export async function getLogoDataUri(): Promise<string | null> {
  try {
    const row = await prisma.siteAsset.findUnique({ where: { id: 1 }, select: { logoData: true } });
    return row?.logoData ?? null;
  } catch {
    // 表还没迁移到、或者查询失败，跟没设置 logo 一样处理，调用方会 fallback 回文字图标
    return null;
  }
}
