import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { getUserAuthSecretBytes } from '@/lib/auth-secret';
import { prisma } from '@/lib/db';

const secret = getUserAuthSecretBytes();
const COOKIE_NAME = 'user_session';

// 跟 lib/auth.ts（管理员）是完全独立的一套：不同的 cookie 名（user_session vs admin_session）、
// 不同的签名密钥（USER_AUTH_SECRET vs AUTH_SECRET）。payload 里额外带一个 role: 'user'，
// 校验时连这个字段一起查——这是防御性的第二层，不是主要防线（主要防线是密钥隔离），
// 万一以后哪天有代码疏忽把两套 cookie 名弄混了，这层校验能兜住。
//
// Secure cookie 只有在 HTTPS 下浏览器才会保留，见 lib/auth.ts 里同样的说明。
const useSecureCookie = process.env.NODE_ENV === 'production' && process.env.COOKIE_INSECURE !== 'true';

type UserSessionPayload = { userId: string; role: 'user' };

export async function createUserSession(userId: string) {
  const token = await new SignJWT({ userId, role: 'user' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: useSecureCookie,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function getUserSessionPayload(): Promise<UserSessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    if (payload.role !== 'user' || typeof payload.userId !== 'string') return null;
    return { userId: payload.userId, role: 'user' };
  } catch {
    return null;
  }
}

export async function clearUserSession() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

// 拿到当前登录用户的完整数据库记录，而不只是 token 里的 userId。
// 私密相册的权限判断一律要用这个，不能只信 session 里带的 userId——
// token 在过期之前签名一直有效，但如果这个用户已经被管理员删掉了，这里会因为
// 查不到对应的 User 记录返回 null，权限判断就能正确地立即拒绝，不用等 token 自然过期。
export async function getCurrentUser() {
  const session = await getUserSessionPayload();
  if (!session) return null;
  return prisma.user.findUnique({ where: { id: session.userId } });
}
