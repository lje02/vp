/**
 * 根据背景色的相对亮度，自动选出对比度更好的文字色（纯黑或纯白）。
 * 用于强调色按钮这类"背景色是用户在后台自定义的，文字色必须跟着适配"的场景——
 * 强调色选深色时用白字，选浅色时用黑字，避免出现黑字配深色背景看不清的问题。
 *
 * 用的是 WCAG 2.x 的相对亮度公式，分别算出黑字、白字相对这个背景色的对比度，
 * 哪个对比度高就选哪个（而不是简单粗暴的亮度阈值二分）。
 */
export function getContrastTextColor(hexColor: string): '#000000' | '#ffffff' {
  const hex = hexColor?.trim().replace(/^#/, '') ?? '';
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return '#000000'; // 不是合法的 6 位 hex，兜底黑字

  const r = parseInt(hex.slice(0, 2), 16) / 255;
  const g = parseInt(hex.slice(2, 4), 16) / 255;
  const b = parseInt(hex.slice(4, 6), 16) / 255;

  const toLinear = (c: number) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
  const bgLuminance = 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);

  const contrastWithBlack = (bgLuminance + 0.05) / 0.05;
  const contrastWithWhite = 1.05 / (bgLuminance + 0.05);

  return contrastWithBlack >= contrastWithWhite ? '#000000' : '#ffffff';
}
