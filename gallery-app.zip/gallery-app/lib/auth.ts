import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { NextResponse } from 'next/server';
import { getAuthSecretBytes } from '@/lib/auth-secret';
import { prisma } from '@/lib/db';

const secret = getAuthSecretBytes();
const COOKIE_NAME = 'admin_session';

// Secure cookie 只有在 HTTPS 下浏览器才会保留，用 http://IP:端口 测试时会被浏览器悄悄丢弃，
// 导致登录看起来成功、但下一个请求就被当成没登录。正式环境配好 HTTPS 后一定要把
// COOKIE_INSECURE 从 .env 里删掉或者设成 false，不然生产环境的登录 cookie 会用不加密的方式传输。
const useSecureCookie = process.env.NODE_ENV === 'production' && process.env.COOKIE_INSECURE !== 'true';

export async function createSession(userId: string) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: useSecureCookie,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function getSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload as { userId: string };
  } catch {
    return null;
  }
}

export async function clearSession() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

// ---------------------------------------------------------------------------
// 下面两个函数是 proxy.ts 之外的第二道防线。
//
// proxy.ts（Next.js 16 里 middleware.ts 的新名字）目前是后台唯一的权限校验点：
// /monkey 和 /api/monkey 下面的页面和接口本身都没有再查一次 session。这在
// proxy.ts 逻辑本身没问题时能正常工作，但 Next.js 官方在 16 的迁移文档里明确提到，
// proxy.ts 不应该被当成唯一的安全边界（这也是当初 middleware 认证绕过漏洞
// CVE-2025-29927 暴露出的问题模式）——它覆盖的是网络边界，不保证一定会在
// 请求真正到达页面渲染 / route handler 之前生效。
//
// 所以这里补一层：受保护页面和后台接口自己也再查一次 session，
// 就算 proxy.ts 那层因为改动、绕过或配置疏漏没有生效，这一层依然会拒绝未登录请求。
// ---------------------------------------------------------------------------

/**
 * 给受保护的页面（Server Component，比如 app/monkey/(protected)/layout.tsx）用。
 * 没有有效 session 时直接跳转到登录页，不往下渲染任何后台数据。
 */
export async function requireAdminPage() {
  const session = await getSession();
  if (!session) {
    redirect('/monkey/login');
  }
  return session;
}

/**
 * 给需要"某个具体模块权限"的后台页面（Server Component）用，没权限直接
 * 跳回 /monkey——那个页面自己会根据当前管理员的权限再找一个能进的地方
 * （见 app/monkey/(protected)/page.tsx），不会死循环。
 */
export async function requirePermissionPage(permission: AdminPermission) {
  const session = await getSession();
  if (!session) {
    redirect('/monkey/login');
  }
  // select 里不能用动态计算出来的 key（比如 [PERMISSION_FIELD[permission]]）——
  // TypeScript/Prisma 没法在编译期确定这个动态 key 到底对应哪个字段，类型推断
  // 会直接跑偏（实测在 `next build` 的类型检查阶段报错，本地 npm run dev 因为
  // 走的是不同的类型检查时机，不一定能第一时间发现）。改成固定把三个权限字段
  // 都选出来，查询本身开销可以忽略（就是三个 boolean 字段），运行时再用普通的
  // 对象属性访问取对应那一个，类型上就是完全静态可推断的了。
  const admin = await prisma.adminUser.findUnique({
    where: { id: session.userId },
    select: { role: true, canManageContent: true, canManageUsers: true, canManageSettings: true },
  });
  const allowed = admin && (admin.role === 'SUPER_ADMIN' || admin[PERMISSION_FIELD[permission]]);
  if (!allowed) {
    redirect('/monkey');
  }
  return session;
}

/**
 * 给管理员管理页面（app/monkey/(protected)/admins/page.tsx）用的页面级门禁。
 * 不是超级管理员的话直接跳回后台首页——这个页面本身不该让子管理员看到，
 * 跟"没登录跳去登录页"是同一个思路，只是判断条件从"有没有 session"
 * 换成了"是不是超级管理员"。
 */
export async function requireSuperAdminPage() {
  const session = await getSession();
  if (!session) {
    redirect('/monkey/login');
  }
  const admin = await prisma.adminUser.findUnique({ where: { id: session.userId }, select: { role: true } });
  if (!admin || admin.role !== 'SUPER_ADMIN') {
    redirect('/monkey');
  }
  return session;
}

/**
 * 给 /api/monkey/* 的 route handler 用。
 * 没有有效 session 时返回一个可以直接 `return` 的 401 响应；
 * 有 session 时返回 session 本身，调用方按需取用 userId。
 *
 * 用法：
 *   const auth = await requireAdminApi();
 *   if ('response' in auth) return auth.response;
 *   // 走到这里说明已登录，auth.session.userId 可用
 */
export async function requireAdminApi(): Promise<
  { session: { userId: string } } | { response: NextResponse }
> {
  const session = await getSession();
  if (!session) {
    return { response: NextResponse.json({ error: '未登录或登录已过期' }, { status: 401 }) };
  }
  return { session };
}

// ---------------------------------------------------------------------------
// 多管理员权限校验（超级管理员 / 按模块授权的子管理员）
//
// 权限信息故意不放进 JWT 里，每次都查一次数据库，跟上面 requireAdminApi() 只
// 校验"有没有登录"的取舍不同——这里要保证"超级管理员刚撤销某个子管理员的权限"
// 这件事立刻生效，而不是等对方持有的 session（有效期 7 天）自然过期。AdminUser
// 表数据量小（几个人的量级），多这一次查询的开销可以忽略。
// ---------------------------------------------------------------------------

export type AdminPermission = 'content' | 'users' | 'settings';

const PERMISSION_FIELD: Record<AdminPermission, 'canManageContent' | 'canManageUsers' | 'canManageSettings'> = {
  content: 'canManageContent',
  users: 'canManageUsers',
  settings: 'canManageSettings',
};

export type CurrentAdmin = {
  id: string;
  email: string;
  role: 'SUPER_ADMIN' | 'ADMIN';
  canManageContent: boolean;
  canManageUsers: boolean;
  canManageSettings: boolean;
};

/**
 * 拿当前登录管理员的完整信息（角色 + 各模块权限），用于后台布局按权限
 * 显示/隐藏导航链接。session 已经在 requireAdminPage() 校验过有效性，
 * 这里假设调用方已经在这之后调用（查不到对应用户说明账号刚好被删了，
 * 返回 null，调用方按未登录处理）。
 */
export async function getCurrentAdmin(): Promise<CurrentAdmin | null> {
  const session = await getSession();
  if (!session) return null;
  const admin = await prisma.adminUser.findUnique({
    where: { id: session.userId },
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
    },
  });
  return admin;
}

/**
 * 给需要"某个具体模块权限"的 /api/monkey/* 接口用（内容/用户/设置三选一）。
 * SUPER_ADMIN 直接放行；ADMIN 看对应的 can* 字段。
 * 用法跟 requireAdminApi() 一致：
 *   const auth = await requirePermissionApi('content');
 *   if ('response' in auth) return auth.response;
 */
export async function requirePermissionApi(
  permission: AdminPermission
): Promise<{ session: { userId: string } } | { response: NextResponse }> {
  const session = await getSession();
  if (!session) {
    return { response: NextResponse.json({ error: '未登录或登录已过期' }, { status: 401 }) };
  }

  // 同 requirePermissionPage() 里的注释：select 不能用动态 key，改成固定选三个
  const admin = await prisma.adminUser.findUnique({
    where: { id: session.userId },
    select: { role: true, canManageContent: true, canManageUsers: true, canManageSettings: true },
  });

  // 账号在别的地方被删了（比如超级管理员刚把这个子管理员账号删掉），
  // session token 签名依然有效，但对应的人已经不存在，一律当未登录处理
  if (!admin) {
    return { response: NextResponse.json({ error: '账号不存在或已被删除' }, { status: 401 }) };
  }

  const allowed = admin.role === 'SUPER_ADMIN' || admin[PERMISSION_FIELD[permission]];
  if (!allowed) {
    return { response: NextResponse.json({ error: '没有权限执行此操作' }, { status: 403 }) };
  }

  return { session };
}

/**
 * 给管理员管理相关接口（新增/编辑/删除其他管理员）用，只有超级管理员能碰。
 * 故意不做成 requirePermissionApi 的第四个 permission 选项——管理员管理
 * 权限不应该是"可以授权给子管理员的一个模块"，这里硬编码成角色判断，
 * 避免以后不小心在某个地方把 canManageAdmins 之类的字段暴露成可勾选项，
 * 导致子管理员能给自己加权限。
 */
export async function requireSuperAdminApi(): Promise<
  { session: { userId: string }; admin: CurrentAdmin } | { response: NextResponse }
> {
  const session = await getSession();
  if (!session) {
    return { response: NextResponse.json({ error: '未登录或登录已过期' }, { status: 401 }) };
  }
  const admin = await prisma.adminUser.findUnique({
    where: { id: session.userId },
    select: {
      id: true,
      email: true,
      role: true,
      canManageContent: true,
      canManageUsers: true,
      canManageSettings: true,
    },
  });
  if (!admin) {
    return { response: NextResponse.json({ error: '账号不存在或已被删除' }, { status: 401 }) };
  }
  if (admin.role !== 'SUPER_ADMIN') {
    return { response: NextResponse.json({ error: '只有超级管理员能执行此操作' }, { status: 403 }) };
  }
  return { session, admin };
}
