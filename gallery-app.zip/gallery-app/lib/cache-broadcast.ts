import { redis } from '@/lib/redis';
import { revalidatePath } from 'next/cache';

// 背景：多节点部署时，nginx-gateway 把后台这次保存设置/导航/分类的请求路由到了某一个节点，
// 那个节点里调用 revalidatePath() 只会清掉"这个节点自己进程里"的 Next.js 页面缓存
// （standalone 部署下每个容器的缓存是各自独立的，没有共享缓存后端）。
// 别的节点还在用各自那份旧缓存，得等 revalidate 的间隔（比如 1 小时）才会自然刷新。
//
// 用 Redis Pub/Sub 广播一下：处理请求的节点发布一条"该刷新哪些路径"的消息，
// 所有节点（包括发布者自己）都订阅同一个频道，收到消息就在本进程里执行一次 revalidatePath，
// 做到管理员保存后，全部节点几乎同时生效，而不是只有被路由到的那一个。
//
// lib/settings.ts / lib/navlinks.ts / lib/categories.ts 里的 Redis 对象缓存不需要这套广播——
// 那些缓存本来就存在共享的 Redis 里，任何节点 del 一次，所有节点下次读到的都是最新的。
// 这里要解决的是 Next.js 自己那层、每个节点各自独立的页面缓存。

const CHANNEL = 'gallery:cache-invalidate';

type PathInvalidation = { path: string; type?: 'layout' | 'page' };
type InvalidationMessage = { paths: PathInvalidation[] };

const globalForBroadcast = globalThis as unknown as { galleryCacheSubscribed?: boolean };

export async function broadcastCacheInvalidation(paths: PathInvalidation[]): Promise<void> {
  if (!redis) return; // 单节点部署没配 Redis 也没关系，调用方自己的 revalidatePath 已经够用
  try {
    const message: InvalidationMessage = { paths };
    await redis.publish(CHANNEL, JSON.stringify(message));
  } catch (err) {
    // 广播失败不影响这次请求本身——本节点已经 revalidatePath 过了，
    // 顶多是别的节点要多等到下次自然 revalidate，不算严重故障
    console.error('[cache-broadcast] publish failed:', err);
  }
}

function applyInvalidation(paths: PathInvalidation[]) {
  for (const { path, type } of paths) {
    try {
      revalidatePath(path, type);
    } catch (err) {
      console.error(`[cache-broadcast] revalidatePath("${path}") failed:`, err);
    }
  }
}

export function subscribeToCacheInvalidation(): void {
  if (!redis) return;
  if (globalForBroadcast.galleryCacheSubscribed) return; // 避免开发环境热重载重复订阅

  // ioredis 的连接一旦进入订阅模式，就只能收消息、不能再发普通命令了，
  // 所以订阅必须用单独一条连接（duplicate() 复用同样的连接参数），不能占用 lib/redis.ts 里
  // 那条给增删改查/限流用的共享连接。
  const subscriber = redis.duplicate();
  subscriber.on('error', (err) => {
    console.error('[cache-broadcast] subscriber connection error:', err.message);
  });

  subscriber.subscribe(CHANNEL).catch((err) => {
    console.error('[cache-broadcast] subscribe failed:', err);
  });

  subscriber.on('message', (_channel, message) => {
    try {
      const parsed = JSON.parse(message) as InvalidationMessage;
      applyInvalidation(parsed.paths);
    } catch (err) {
      console.error('[cache-broadcast] failed to parse invalidation message:', err);
    }
  });

  globalForBroadcast.galleryCacheSubscribed = true;
}

subscribeToCacheInvalidation();
